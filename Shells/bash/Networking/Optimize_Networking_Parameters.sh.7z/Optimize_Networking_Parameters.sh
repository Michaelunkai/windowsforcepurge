#!/bin/bash
# Set optimal network parameters
sysctl -w net.ipv4.tcp_window_scaling=1
