import sql from "@/app/api/utils/sql";

// Get single project
export async function GET(request, { params }) {
  try {
    const { id } = params;
    const [project] = await sql`
      SELECT p.*, 
             COUNT(DISTINCT n.id) as note_count,
             COUNT(DISTINCT t.id) as task_count
      FROM projects p
      LEFT JOIN notes n ON p.id = n.project_id
      LEFT JOIN tasks t ON p.id = t.project_id
      WHERE p.id = ${id}
      GROUP BY p.id
    `;
    
    if (!project) {
      return Response.json({ error: 'Project not found' }, { status: 404 });
    }
    
    return Response.json({ project });
  } catch (error) {
    console.error('Error fetching project:', error);
    return Response.json({ error: 'Failed to fetch project' }, { status: 500 });
  }
}

// Update project
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    
    // Build dynamic update query
    const updateFields = [];
    const values = [];
    let paramCount = 1;
    
    if (body.name !== undefined) {
      updateFields.push(`name = $${paramCount}`);
      values.push(body.name);
      paramCount++;
    }
    
    if (body.color !== undefined) {
      updateFields.push(`color = $${paramCount}`);
      values.push(body.color);
      paramCount++;
    }
    
    if (body.description !== undefined) {
      updateFields.push(`description = $${paramCount}`);
      values.push(body.description);
      paramCount++;
    }
    
    if (updateFields.length === 0) {
      return Response.json({ error: 'No fields to update' }, { status: 400 });
    }
    
    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(id);
    
    const query = `
      UPDATE projects 
      SET ${updateFields.join(', ')}
      WHERE id = $${paramCount}
      RETURNING *
    `;
    
    const [project] = await sql(query, values);
    
    if (!project) {
      return Response.json({ error: 'Project not found' }, { status: 404 });
    }
    
    return Response.json({ project });
  } catch (error) {
    console.error('Error updating project:', error);
    if (error.code === '23505') { // Unique constraint violation
      return Response.json({ error: 'Project name already exists' }, { status: 409 });
    }
    return Response.json({ error: 'Failed to update project' }, { status: 500 });
  }
}

// Delete project
export async function DELETE(request, { params }) {
  try {
    const { id } = params;
    
    // Check if project has notes or tasks
    const [counts] = await sql`
      SELECT 
        COUNT(DISTINCT n.id) as note_count,
        COUNT(DISTINCT t.id) as task_count
      FROM projects p
      LEFT JOIN notes n ON p.id = n.project_id
      LEFT JOIN tasks t ON p.id = t.project_id
      WHERE p.id = ${id}
      GROUP BY p.id
    `;
    
    if (counts && (parseInt(counts.note_count) > 0 || parseInt(counts.task_count) > 0)) {
      return Response.json({ 
        error: 'Cannot delete project with existing notes or tasks. Move them to another project first.' 
      }, { status: 409 });
    }
    
    const [project] = await sql`
      DELETE FROM projects WHERE id = ${id} RETURNING *
    `;
    
    if (!project) {
      return Response.json({ error: 'Project not found' }, { status: 404 });
    }
    
    return Response.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Error deleting project:', error);
    return Response.json({ error: 'Failed to delete project' }, { status: 500 });
  }
}