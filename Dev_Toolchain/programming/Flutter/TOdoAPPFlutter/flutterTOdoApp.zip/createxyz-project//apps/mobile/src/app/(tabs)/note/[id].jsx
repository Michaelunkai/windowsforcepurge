import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  Keyboard,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Check, Pin, Palette, MoreVertical } from 'lucide-react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import KeyboardAvoidingAnimatedView from '@/components/KeyboardAvoidingAnimatedView';

const NOTE_COLORS = [
  '#FFFFFF', '#FFE082', '#FFCDD2', '#F8BBD9', '#E1BEE7',
  '#C5CAE9', '#BBDEFB', '#B2DFDB', '#C8E6C9', '#DCEDC8'
];

export default function NoteEditorScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const queryClient = useQueryClient();
  const isNewNote = id === 'new';

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [color, setColor] = useState('#FFFFFF');
  const [isPinned, setIsPinned] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  // Fetch existing note
  const { data: noteData, isLoading } = useQuery({
    queryKey: ['note', id],
    queryFn: async () => {
      if (isNewNote) return null;
      const response = await fetch(`/api/notes/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch note');
      }
      return response.json();
    },
    enabled: !isNewNote,
  });

  // Initialize form with existing note data
  useEffect(() => {
    if (noteData?.note && !isNewNote) {
      setTitle(noteData.note.title || '');
      setContent(noteData.note.content || '');
      setColor(noteData.note.color || '#FFFFFF');
      setIsPinned(noteData.note.is_pinned || false);
    }
  }, [noteData, isNewNote]);

  // Track changes
  useEffect(() => {
    if (!isNewNote && noteData?.note) {
      const originalNote = noteData.note;
      const hasChanged = 
        title !== (originalNote.title || '') ||
        content !== (originalNote.content || '') ||
        color !== (originalNote.color || '#FFFFFF') ||
        isPinned !== (originalNote.is_pinned || false);
      setHasChanges(hasChanged);
    } else if (isNewNote) {
      setHasChanges(title.trim() !== '' || content.trim() !== '');
    }
  }, [title, content, color, isPinned, noteData, isNewNote]);

  // Save note mutation
  const saveNoteMutation = useMutation({
    mutationFn: async (noteData) => {
      const url = isNewNote ? '/api/notes' : `/api/notes/${id}`;
      const method = isNewNote ? 'POST' : 'PUT';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(noteData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to save note');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      queryClient.invalidateQueries({ queryKey: ['note', id] });
      setHasChanges(false);
      router.back();
    },
    onError: () => {
      Alert.alert('Error', 'Failed to save note');
    },
  });

  // Delete note mutation
  const deleteNoteMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/notes/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error('Failed to delete note');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      router.back();
    },
    onError: () => {
      Alert.alert('Error', 'Failed to delete note');
    },
  });

  const handleSave = useCallback(() => {
    if (!hasChanges) {
      router.back();
      return;
    }

    const noteData = {
      title: title.trim(),
      content: content.trim(),
      color,
      is_pinned: isPinned,
    };

    saveNoteMutation.mutate(noteData);
  }, [title, content, color, isPinned, hasChanges, saveNoteMutation, router]);

  const handleBack = useCallback(() => {
    if (hasChanges) {
      Alert.alert(
        'Unsaved Changes',
        'You have unsaved changes. What would you like to do?',
        [
          { text: 'Discard', style: 'destructive', onPress: () => router.back() },
          { text: 'Save', onPress: handleSave },
          { text: 'Cancel', style: 'cancel' },
        ]
      );
    } else {
      router.back();
    }
  }, [hasChanges, handleSave, router]);

  const handleDelete = useCallback(() => {
    if (isNewNote) return;
    
    Alert.alert(
      'Delete Note',
      'Are you sure you want to delete this note?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive', 
          onPress: () => deleteNoteMutation.mutate() 
        },
      ]
    );
  }, [isNewNote, deleteNoteMutation]);

  const handleMoreOptions = useCallback(() => {
    const options = [
      { 
        text: isPinned ? 'Unpin' : 'Pin', 
        onPress: () => setIsPinned(!isPinned) 
      },
      { 
        text: 'Colors', 
        onPress: () => setShowColorPicker(!showColorPicker) 
      },
    ];

    if (!isNewNote) {
      options.push({ 
        text: 'Delete', 
        style: 'destructive',
        onPress: handleDelete 
      });
    }

    options.push({ text: 'Cancel', style: 'cancel' });

    Alert.alert('Note Options', 'Choose an action', options);
  }, [isPinned, showColorPicker, isNewNote, handleDelete]);

  const renderColorPicker = () => (
    <View style={{
      flexDirection: 'row',
      flexWrap: 'wrap',
      paddingHorizontal: 20,
      paddingVertical: 16,
      backgroundColor: '#F8F9FA',
      borderBottomWidth: 1,
      borderBottomColor: '#E5E7EB',
    }}>
      {NOTE_COLORS.map((noteColor) => (
        <TouchableOpacity
          key={noteColor}
          style={{
            width: 32,
            height: 32,
            borderRadius: 16,
            backgroundColor: noteColor,
            margin: 4,
            borderWidth: color === noteColor ? 3 : 1,
            borderColor: color === noteColor ? '#1976D2' : '#E5E7EB',
          }}
          onPress={() => setColor(noteColor)}
        />
      ))}
    </View>
  );

  if (isLoading && !isNewNote) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
      <View style={{ flex: 1, backgroundColor: color }}>
        <StatusBar style="dark" />
        
        {/* Header */}
        <View style={{ 
          paddingTop: insets.top + 16,
          paddingHorizontal: 20,
          paddingBottom: 16,
          backgroundColor: color,
          borderBottomWidth: showColorPicker ? 0 : 1,
          borderBottomColor: '#E5E7EB',
        }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <TouchableOpacity onPress={handleBack}>
              <ArrowLeft size={24} color="#333" />
            </TouchableOpacity>
            
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              {isPinned && (
                <Pin size={20} color="#666" style={{ marginRight: 12 }} />
              )}
              <TouchableOpacity
                onPress={() => setShowColorPicker(!showColorPicker)}
                style={{ marginRight: 12 }}
              >
                <Palette size={24} color="#333" />
              </TouchableOpacity>
              <TouchableOpacity onPress={handleMoreOptions} style={{ marginRight: 12 }}>
                <MoreVertical size={24} color="#333" />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleSave}
                disabled={!hasChanges || saveNoteMutation.isLoading}
                style={{
                  backgroundColor: hasChanges ? '#1976D2' : '#E5E7EB',
                  borderRadius: 20,
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                }}
              >
                <Check size={20} color={hasChanges ? '#FFFFFF' : '#999'} />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Color Picker */}
        {showColorPicker && renderColorPicker()}

        {/* Note Content */}
        <ScrollView 
          style={{ flex: 1 }}
          contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 20 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <TextInput
            value={title}
            onChangeText={setTitle}
            placeholder="Note title"
            style={{
              fontSize: 24,
              fontWeight: '600',
              color: '#333',
              marginBottom: 16,
              textAlignVertical: 'top',
            }}
            multiline
            placeholderTextColor="#999"
          />
          
          <TextInput
            value={content}
            onChangeText={setContent}
            placeholder="Start writing..."
            style={{
              fontSize: 16,
              color: '#333',
              lineHeight: 24,
              minHeight: 200,
              textAlignVertical: 'top',
            }}
            multiline
            placeholderTextColor="#999"
          />
        </ScrollView>
      </View>
    </KeyboardAvoidingAnimatedView>
  );
}