import sql from "@/app/api/utils/sql";

// Search notes and tasks with project information
export async function GET(request) {
  try {
    const url = new URL(request.url);
    const query = url.searchParams.get("q");

    if (!query) {
      return Response.json({ notes: [], tasks: [] });
    }

    const searchTerm = `%${query.toLowerCase()}%`;

    const [notes, tasks] = await sql.transaction([
      sql`
        SELECT n.*, p.name as project_name, p.color as project_color
        FROM notes n 
        LEFT JOIN projects p ON n.project_id = p.id
        WHERE LOWER(n.title) LIKE ${searchTerm} 
           OR LOWER(n.content) LIKE ${searchTerm}
           OR LOWER(p.name) LIKE ${searchTerm}
        ORDER BY n.is_pinned DESC, n.updated_at DESC
        LIMIT 20
      `,
      sql`
        SELECT t.*, 
               p.name as project_name,
               p.color as project_color,
               json_agg(
                 json_build_object(
                   'id', s.id,
                   'title', s.title,
                   'is_completed', s.is_completed,
                   'created_at', s.created_at
                 ) ORDER BY s.created_at
               ) FILTER (WHERE s.id IS NOT NULL) as subtasks
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN subtasks s ON t.id = s.task_id
        WHERE LOWER(t.title) LIKE ${searchTerm} 
           OR LOWER(t.description) LIKE ${searchTerm}
           OR LOWER(p.name) LIKE ${searchTerm}
        GROUP BY t.id, p.name, p.color
        ORDER BY t.is_completed ASC, t.created_at DESC
        LIMIT 20
      `,
    ]);

    return Response.json({ notes, tasks });
  } catch (error) {
    console.error("Error searching:", error);
    return Response.json({ error: "Failed to search" }, { status: 500 });
  }
}
