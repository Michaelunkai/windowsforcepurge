import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Dimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery } from '@tanstack/react-query';
import { 
  Search as SearchIcon, 
  FileText, 
  CheckSquare,
  Pin,
  Flag,
  Calendar,
  X
} from 'lucide-react-native';
import { useRouter } from 'expo-router';

const { width } = Dimensions.get('window');
const CARD_MARGIN = 8;
const CARDS_PER_ROW = 2;
const CARD_WIDTH = (width - (CARD_MARGIN * (CARDS_PER_ROW + 1))) / CARDS_PER_ROW;

const PRIORITY_COLORS = {
  urgent: '#FF5722',
  high: '#FF9800',
  medium: '#2196F3',
  low: '#4CAF50',
};

export default function SearchScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Search query
  const { data: searchData, isLoading } = useQuery({
    queryKey: ['search', debouncedQuery],
    queryFn: async () => {
      if (!debouncedQuery.trim()) return { notes: [], tasks: [] };
      
      const response = await fetch(`/api/search?q=${encodeURIComponent(debouncedQuery)}`);
      if (!response.ok) {
        throw new Error('Failed to search');
      }
      return response.json();
    },
    enabled: debouncedQuery.trim().length > 0,
  });

  const notes = searchData?.notes || [];
  const tasks = searchData?.tasks || [];
  const hasResults = notes.length > 0 || tasks.length > 0;

  const handleNotePress = useCallback((noteId) => {
    router.push(`/note/${noteId}`);
  }, [router]);

  const handleTaskPress = useCallback((taskId) => {
    router.push(`/task/${taskId}`);
  }, [router]);

  const clearSearch = useCallback(() => {
    setSearchQuery('');
  }, []);

  const formatDueDate = (dateString) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = date - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays === -1) return 'Yesterday';
    if (diffDays < 0) return `${Math.abs(diffDays)} days ago`;
    if (diffDays <= 7) return `${diffDays} days`;
    
    return date.toLocaleDateString();
  };

  const renderNoteCard = ({ item: note }) => (
    <TouchableOpacity
      style={{
        width: CARD_WIDTH,
        backgroundColor: note.color || '#FFFFFF',
        borderRadius: 12,
        padding: 16,
        margin: CARD_MARGIN / 2,
        minHeight: 120,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
      }}
      onPress={() => handleNotePress(note.id)}
      activeOpacity={0.7}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
        <FileText size={16} color="#666" />
        {note.is_pinned && (
          <Pin size={16} color="#666" />
        )}
      </View>
      
      {note.title ? (
        <Text
          style={{
            fontSize: 16,
            fontWeight: '600',
            color: '#333',
            marginBottom: 8,
          }}
          numberOfLines={2}
        >
          {note.title}
        </Text>
      ) : null}
      
      {note.content ? (
        <Text
          style={{
            fontSize: 14,
            color: '#666',
            lineHeight: 20,
          }}
          numberOfLines={note.title ? 4 : 6}
        >
          {note.content}
        </Text>
      ) : null}
      
      <Text
        style={{
          fontSize: 12,
          color: '#999',
          marginTop: 'auto',
          paddingTop: 8,
        }}
      >
        {new Date(note.updated_at).toLocaleDateString()}
      </Text>
    </TouchableOpacity>
  );

  const renderTaskItem = ({ item: task }) => (
    <TouchableOpacity
      style={{
        backgroundColor: '#FFFFFF',
        borderRadius: 12,
        padding: 16,
        marginHorizontal: 16,
        marginVertical: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 2,
        opacity: task.is_completed ? 0.6 : 1,
      }}
      onPress={() => handleTaskPress(task.id)}
      activeOpacity={0.7}
    >
      <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
        <CheckSquare 
          size={20} 
          color={task.is_completed ? '#4CAF50' : '#999'} 
          style={{ marginRight: 12, marginTop: 2 }}
        />
        
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 16,
              fontWeight: '600',
              color: task.is_completed ? '#999' : '#333',
              textDecorationLine: task.is_completed ? 'line-through' : 'none',
              marginBottom: 4,
            }}
            numberOfLines={2}
          >
            {task.title}
          </Text>
          
          {task.description ? (
            <Text
              style={{
                fontSize: 14,
                color: '#666',
                marginBottom: 8,
                lineHeight: 20,
              }}
              numberOfLines={2}
            >
              {task.description}
            </Text>
          ) : null}
          
          <View style={{ flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' }}>
            {/* Priority */}
            <View style={{
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: PRIORITY_COLORS[task.priority],
              borderRadius: 12,
              paddingHorizontal: 8,
              paddingVertical: 4,
              marginRight: 8,
              marginBottom: 4,
            }}>
              <Flag size={12} color="#FFFFFF" />
              <Text style={{ fontSize: 12, color: '#FFFFFF', marginLeft: 4, fontWeight: '500' }}>
                {task.priority}
              </Text>
            </View>
            
            {/* Project */}
            <View style={{
              backgroundColor: '#F3F4F6',
              borderRadius: 12,
              paddingHorizontal: 8,
              paddingVertical: 4,
              marginRight: 8,
              marginBottom: 4,
            }}>
              <Text style={{ fontSize: 12, color: '#666', fontWeight: '500' }}>
                {task.project}
              </Text>
            </View>
            
            {/* Due Date */}
            {task.due_date && (
              <View style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#FEF3C7',
                borderRadius: 12,
                paddingHorizontal: 8,
                paddingVertical: 4,
                marginBottom: 4,
              }}>
                <Calendar size={12} color="#D97706" />
                <Text style={{ fontSize: 12, color: '#D97706', marginLeft: 4, fontWeight: '500' }}>
                  {formatDueDate(task.due_date)}
                </Text>
              </View>
            )}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderEmptyState = () => {
    if (searchQuery.trim() === '') {
      return (
        <View style={{ 
          flex: 1, 
          justifyContent: 'center', 
          alignItems: 'center',
          paddingHorizontal: 32,
        }}>
          <SearchIcon size={64} color="#CCC" />
          <Text style={{ 
            fontSize: 18, 
            fontWeight: '600', 
            color: '#666',
            marginTop: 16,
            marginBottom: 8,
            textAlign: 'center',
          }}>
            Search your notes and tasks
          </Text>
          <Text style={{ 
            fontSize: 14, 
            color: '#999',
            textAlign: 'center',
            lineHeight: 20,
          }}>
            Type in the search box above to find your content
          </Text>
        </View>
      );
    }

    if (!isLoading && !hasResults) {
      return (
        <View style={{ 
          flex: 1, 
          justifyContent: 'center', 
          alignItems: 'center',
          paddingHorizontal: 32,
        }}>
          <SearchIcon size={64} color="#CCC" />
          <Text style={{ 
            fontSize: 18, 
            fontWeight: '600', 
            color: '#666',
            marginTop: 16,
            marginBottom: 8,
            textAlign: 'center',
          }}>
            No results found
          </Text>
          <Text style={{ 
            fontSize: 14, 
            color: '#999',
            textAlign: 'center',
            lineHeight: 20,
          }}>
            Try searching with different keywords
          </Text>
        </View>
      );
    }

    return null;
  };

  const renderResults = () => {
    if (!hasResults) return null;

    return (
      <FlatList
        data={[
          ...(notes.length > 0 ? [{ type: 'section', title: 'Notes', data: notes }] : []),
          ...(tasks.length > 0 ? [{ type: 'section', title: 'Tasks', data: tasks }] : []),
        ]}
        keyExtractor={(item, index) => `${item.type}-${index}`}
        renderItem={({ item }) => {
          if (item.type === 'section') {
            return (
              <View style={{ marginBottom: 16 }}>
                <Text style={{ 
                  fontSize: 20, 
                  fontWeight: '700', 
                  color: '#333',
                  marginHorizontal: 16,
                  marginBottom: 12,
                }}>
                  {item.title}
                </Text>
                
                {item.title === 'Notes' ? (
                  <FlatList
                    data={item.data}
                    renderItem={renderNoteCard}
                    keyExtractor={(note) => `note-${note.id}`}
                    numColumns={CARDS_PER_ROW}
                    scrollEnabled={false}
                    contentContainerStyle={{ paddingHorizontal: CARD_MARGIN / 2 }}
                  />
                ) : (
                  <FlatList
                    data={item.data}
                    renderItem={renderTaskItem}
                    keyExtractor={(task) => `task-${task.id}`}
                    scrollEnabled={false}
                  />
                )}
              </View>
            );
          }
          return null;
        }}
        contentContainerStyle={{ 
          paddingVertical: 16,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      />
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#F8F9FA' }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ 
        paddingTop: insets.top + 16,
        paddingHorizontal: 20,
        paddingBottom: 16,
        backgroundColor: '#FFFFFF',
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB',
      }}>
        <Text style={{ fontSize: 28, fontWeight: '700', color: '#1F2937', marginBottom: 16 }}>
          Search
        </Text>
        
        {/* Search Input */}
        <View style={{
          flexDirection: 'row',
          alignItems: 'center',
          backgroundColor: '#F8F9FA',
          borderRadius: 12,
          paddingHorizontal: 16,
          paddingVertical: 12,
        }}>
          <SearchIcon size={20} color="#666" style={{ marginRight: 12 }} />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search notes and tasks..."
            style={{
              flex: 1,
              fontSize: 16,
              color: '#333',
            }}
            placeholderTextColor="#999"
            returnKeyType="search"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={clearSearch} style={{ marginLeft: 8 }}>
              <X size={20} color="#666" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Results */}
      {hasResults ? renderResults() : renderEmptyState()}
    </View>
  );
}