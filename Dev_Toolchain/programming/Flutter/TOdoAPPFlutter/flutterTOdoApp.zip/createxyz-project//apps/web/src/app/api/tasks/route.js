import sql from "@/app/api/utils/sql";

// Get all tasks with subtasks and project information
export async function GET(request) {
  try {
    const url = new URL(request.url);
    const project_id = url.searchParams.get("project_id");
    const completed = url.searchParams.get("completed");
    const date = url.searchParams.get("date"); // For calendar view

    let query = `
      SELECT t.*, 
             p.name as project_name,
             p.color as project_color,
             json_agg(
               json_build_object(
                 'id', s.id,
                 'title', s.title,
                 'is_completed', s.is_completed,
                 'created_at', s.created_at
               ) ORDER BY s.created_at
             ) FILTER (WHERE s.id IS NOT NULL) as subtasks
      FROM tasks t
      LEFT JOIN projects p ON t.project_id = p.id
      LEFT JOIN subtasks s ON t.id = s.task_id
      WHERE 1=1
    `;

    const values = [];
    let paramCount = 1;

    if (project_id) {
      query += ` AND t.project_id = $${paramCount}`;
      values.push(project_id);
      paramCount++;
    }

    if (completed !== null) {
      query += ` AND t.is_completed = $${paramCount}`;
      values.push(completed === "true");
      paramCount++;
    }

    if (date) {
      query += ` AND DATE(t.due_date) = DATE($${paramCount})`;
      values.push(date);
      paramCount++;
    }

    query += `
      GROUP BY t.id, p.name, p.color
      ORDER BY t.is_completed ASC, 
               CASE t.priority 
                 WHEN 'urgent' THEN 1 
                 WHEN 'high' THEN 2 
                 WHEN 'medium' THEN 3 
                 WHEN 'low' THEN 4 
               END,
               t.due_date ASC NULLS LAST,
               t.created_at DESC
    `;

    const tasks = await sql(query, values);
    return Response.json({ tasks });
  } catch (error) {
    console.error("Error fetching tasks:", error);
    return Response.json({ error: "Failed to fetch tasks" }, { status: 500 });
  }
}

// Create new task
export async function POST(request) {
  try {
    const {
      title,
      description = "",
      priority = "medium",
      due_date,
      project_id,
      subtasks = [],
    } = await request.json();

    if (!title) {
      return Response.json({ error: "Title is required" }, { status: 400 });
    }

    const [task, createdSubtasks] = await sql.transaction([
      sql`
        INSERT INTO tasks (title, description, priority, due_date, project_id, updated_at)
        VALUES (${title}, ${description}, ${priority}, ${due_date || null}, ${project_id || null}, CURRENT_TIMESTAMP)
        RETURNING *
      `,
      ...(subtasks.length > 0
        ? [
            sql`
          INSERT INTO subtasks (task_id, title)
          SELECT t.id, unnest(${subtasks}::text[])
          FROM tasks t
          WHERE t.title = ${title} AND t.created_at = (SELECT MAX(created_at) FROM tasks WHERE title = ${title})
          RETURNING *
        `,
          ]
        : []),
    ]);

    return Response.json({
      task: {
        ...task,
        subtasks: createdSubtasks || [],
      },
    });
  } catch (error) {
    console.error("Error creating task:", error);
    return Response.json({ error: "Failed to create task" }, { status: 500 });
  }
}
