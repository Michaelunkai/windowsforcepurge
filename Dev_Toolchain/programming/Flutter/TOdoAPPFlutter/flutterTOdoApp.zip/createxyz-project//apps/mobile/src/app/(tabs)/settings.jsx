import React, { useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Alert,
  Linking,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  User,
  Bell,
  Palette,
  Download,
  Upload,
  HelpCircle,
  Info,
  ChevronRight,
  Database,
  Trash2
} from 'lucide-react-native';
import { useQueryClient, useMutation } from '@tanstack/react-query';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();

  // Clear all data mutation
  const clearDataMutation = useMutation({
    mutationFn: async () => {
      // This would need to be implemented as an API endpoint
      // For now, we'll just clear the local cache
      queryClient.clear();
    },
    onSuccess: () => {
      Alert.alert('Success', 'All data has been cleared from the app');
    },
    onError: () => {
      Alert.alert('Error', 'Failed to clear data');
    },
  });

  const handleClearData = useCallback(() => {
    Alert.alert(
      'Clear All Data',
      'This will remove all your notes and tasks from the app. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear All', 
          style: 'destructive', 
          onPress: () => clearDataMutation.mutate() 
        },
      ]
    );
  }, [clearDataMutation]);

  const handleExportData = useCallback(() => {
    Alert.alert(
      'Export Data',
      'Export functionality would allow you to backup your notes and tasks.',
      [{ text: 'OK' }]
    );
  }, []);

  const handleImportData = useCallback(() => {
    Alert.alert(
      'Import Data',
      'Import functionality would allow you to restore your notes and tasks from a backup.',
      [{ text: 'OK' }]
    );
  }, []);

  const handleNotifications = useCallback(() => {
    Alert.alert(
      'Notifications',
      'Notification settings would allow you to configure reminders for your tasks.',
      [{ text: 'OK' }]
    );
  }, []);

  const handleTheme = useCallback(() => {
    Alert.alert(
      'Theme',
      'Theme settings would allow you to customize the app appearance.',
      [{ text: 'OK' }]
    );
  }, []);

  const handleHelp = useCallback(() => {
    Alert.alert(
      'Help & Support',
      'Here you would find tutorials, FAQs, and contact information for support.',
      [{ text: 'OK' }]
    );
  }, []);

  const handleAbout = useCallback(() => {
    Alert.alert(
      'About',
      'Notes & Tasks App\nVersion 1.0.0\n\nA powerful productivity app inspired by Samsung Notes and Todoist.',
      [{ text: 'OK' }]
    );
  }, []);

  const renderSettingItem = ({ icon: Icon, title, subtitle, onPress, color = '#333', showChevron = true }) => (
    <TouchableOpacity
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        paddingHorizontal: 20,
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#F3F4F6',
      }}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={{
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: '#F8F9FA',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 16,
      }}>
        <Icon size={20} color={color} />
      </View>
      
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 2 }}>
          {title}
        </Text>
        {subtitle && (
          <Text style={{ fontSize: 14, color: '#666' }}>
            {subtitle}
          </Text>
        )}
      </View>
      
      {showChevron && (
        <ChevronRight size={20} color="#999" />
      )}
    </TouchableOpacity>
  );

  const renderSectionHeader = (title) => (
    <Text style={{
      fontSize: 14,
      fontWeight: '600',
      color: '#666',
      textTransform: 'uppercase',
      letterSpacing: 0.5,
      marginHorizontal: 20,
      marginTop: 32,
      marginBottom: 8,
    }}>
      {title}
    </Text>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#F8F9FA' }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ 
        paddingTop: insets.top + 16,
        paddingHorizontal: 20,
        paddingBottom: 16,
        backgroundColor: '#FFFFFF',
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB',
      }}>
        <Text style={{ fontSize: 28, fontWeight: '700', color: '#1F2937' }}>
          Settings
        </Text>
      </View>

      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Account Section */}
        {renderSectionHeader('Account')}
        {renderSettingItem({
          icon: User,
          title: 'Profile',
          subtitle: 'Manage your account settings',
          onPress: () => Alert.alert('Profile', 'Profile settings would be available here'),
        })}

        {/* Preferences Section */}
        {renderSectionHeader('Preferences')}
        {renderSettingItem({
          icon: Bell,
          title: 'Notifications',
          subtitle: 'Configure reminders and alerts',
          onPress: handleNotifications,
        })}
        {renderSettingItem({
          icon: Palette,
          title: 'Theme',
          subtitle: 'Customize app appearance',
          onPress: handleTheme,
        })}

        {/* Data Section */}
        {renderSectionHeader('Data')}
        {renderSettingItem({
          icon: Upload,
          title: 'Export Data',
          subtitle: 'Backup your notes and tasks',
          onPress: handleExportData,
        })}
        {renderSettingItem({
          icon: Download,
          title: 'Import Data',
          subtitle: 'Restore from backup',
          onPress: handleImportData,
        })}
        {renderSettingItem({
          icon: Trash2,
          title: 'Clear All Data',
          subtitle: 'Remove all notes and tasks',
          onPress: handleClearData,
          color: '#FF5722',
        })}

        {/* Support Section */}
        {renderSectionHeader('Support')}
        {renderSettingItem({
          icon: HelpCircle,
          title: 'Help & Support',
          subtitle: 'Get help and contact support',
          onPress: handleHelp,
        })}
        {renderSettingItem({
          icon: Info,
          title: 'About',
          subtitle: 'App version and information',
          onPress: handleAbout,
        })}

        {/* App Info */}
        <View style={{ 
          alignItems: 'center', 
          marginTop: 40,
          paddingHorizontal: 20,
        }}>
          <Text style={{ fontSize: 14, color: '#999', textAlign: 'center', lineHeight: 20 }}>
            Notes & Tasks App
          </Text>
          <Text style={{ fontSize: 12, color: '#CCC', marginTop: 4 }}>
            Version 1.0.0
          </Text>
          <Text style={{ fontSize: 12, color: '#CCC', marginTop: 8, textAlign: 'center' }}>
            Inspired by Samsung Notes and Todoist
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}