import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  FlatList,
  Alert,
  RefreshControl,
  Modal,
  TextInput,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Plus, 
  CheckSquare, 
  Square, 
  Calendar, 
  Flag,
  MoreVertical,
  CheckCircle2,
  Circle,
  FileText,
  Edit,
  Trash2,
  Folder
} from 'lucide-react-native';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';

const PRIORITY_COLORS = {
  urgent: '#FF5722',
  high: '#FF9800',
  medium: '#2196F3',
  low: '#4CAF50',
};

const PRIORITY_LABELS = {
  urgent: 'Urgent',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
};

export default function TasksScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);
  
  // Modal states
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showActionsModal, setShowActionsModal] = useState(false);
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [createType, setCreateType] = useState('task');
  const [selectedProject, setSelectedProject] = useState(null);
  
  // Form states
  const [newItemTitle, setNewItemTitle] = useState('');

  // Fetch tasks with project information
  const { data: tasksData, isLoading, error } = useQuery({
    queryKey: ['tasks'],
    queryFn: async () => {
      const response = await fetch('/api/tasks');
      if (!response.ok) {
        throw new Error('Failed to fetch tasks');
      }
      return response.json();
    },
    refetchInterval: 5000, // Real-time sync every 5 seconds
  });

  // Fetch projects
  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: async () => {
      const response = await fetch('/api/projects');
      if (!response.ok) throw new Error('Failed to fetch projects');
      const data = await response.json();
      return data.projects;
    },
    refetchInterval: 5000,
  });

  const tasks = tasksData?.tasks || [];

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (taskData) => {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(taskData),
      });
      if (!response.ok) throw new Error('Failed to create task');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setShowCreateModal(false);
      setNewItemTitle('');
      setSelectedProject(null);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    },
  });

  // Create note mutation
  const createNoteMutation = useMutation({
    mutationFn: async (noteData) => {
      const response = await fetch('/api/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(noteData),
      });
      if (!response.ok) throw new Error('Failed to create note');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      setShowCreateModal(false);
      setNewItemTitle('');
      setSelectedProject(null);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    },
  });

  // Toggle task completion mutation
  const toggleTaskMutation = useMutation({
    mutationFn: async ({ id, is_completed }) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_completed: !is_completed }),
      });
      if (!response.ok) {
        throw new Error('Failed to update task');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
    },
    onError: () => {
      Alert.alert('Error', 'Failed to update task');
    },
  });

  // Update task project mutation
  const updateTaskProjectMutation = useMutation({
    mutationFn: async ({ id, project_id }) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project_id }),
      });
      if (!response.ok) throw new Error('Failed to update task');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setShowProjectModal(false);
      setSelectedTask(null);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    },
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error('Failed to delete task');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setShowActionsModal(false);
      setSelectedTask(null);
    },
    onError: () => {
      Alert.alert('Error', 'Failed to delete task');
    },
  });

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ['tasks'] });
    setRefreshing(false);
  }, [queryClient]);

  const handleCreateItem = useCallback(() => {
    if (!newItemTitle.trim()) return;
    
    if (createType === 'task') {
      createTaskMutation.mutate({
        title: newItemTitle.trim(),
        project_id: selectedProject?.id || null,
      });
    } else if (createType === 'note') {
      createNoteMutation.mutate({
        title: newItemTitle.trim(),
        project_id: selectedProject?.id || null,
      });
    }
  }, [newItemTitle, createType, selectedProject, createTaskMutation, createNoteMutation]);

  const handleTaskPress = useCallback((taskId) => {
    router.push(`/(tabs)/task/${taskId}`);
  }, [router]);

  const handleToggleTask = useCallback((task) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    toggleTaskMutation.mutate({ id: task.id, is_completed: task.is_completed });
  }, [toggleTaskMutation]);

  const handleDeleteTask = useCallback(() => {
    if (!selectedTask) return;
    
    Alert.alert(
      'Delete Task',
      `Are you sure you want to delete "${selectedTask.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive', 
          onPress: () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
            deleteTaskMutation.mutate(selectedTask.id);
          }
        },
      ]
    );
  }, [selectedTask, deleteTaskMutation]);

  const handleEditTask = useCallback(() => {
    if (!selectedTask) return;
    setShowActionsModal(false);
    router.push(`/(tabs)/task/${selectedTask.id}`);
  }, [selectedTask, router]);

  const handleAssignProject = useCallback((projectId) => {
    if (!selectedTask) return;
    updateTaskProjectMutation.mutate({
      id: selectedTask.id,
      project_id: projectId,
    });
  }, [selectedTask, updateTaskProjectMutation]);

  const handleTaskLongPress = useCallback((task) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSelectedTask(task);
    setShowActionsModal(true);
  }, []);

  const formatDueDate = (dateString) => {
    if (!dateString) return null;
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = date - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays === -1) return 'Yesterday';
    if (diffDays < 0) return `${Math.abs(diffDays)} days ago`;
    if (diffDays <= 7) return `${diffDays} days`;
    
    return date.toLocaleDateString();
  };

  const renderSubtasks = (subtasks) => {
    if (!subtasks || subtasks.length === 0) return null;
    
    const completedCount = subtasks.filter(st => st.is_completed).length;
    return (
      <Text style={{ fontSize: 12, color: '#666666', marginTop: 4 }}>
        {completedCount}/{subtasks.length} subtasks completed
      </Text>
    );
  };

  const renderTaskItem = ({ item: task }) => (
    <TouchableOpacity
      style={{
        backgroundColor: '#111111',
        borderRadius: 12,
        padding: 16,
        marginHorizontal: 16,
        marginVertical: 4,
        borderWidth: 1,
        borderColor: '#333333',
        opacity: task.is_completed ? 0.6 : 1,
      }}
      onPress={() => handleTaskPress(task.id)}
      onLongPress={() => handleTaskLongPress(task)}
      activeOpacity={0.7}
    >
      <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
        <TouchableOpacity
          onPress={() => handleToggleTask(task)}
          style={{ marginRight: 12, marginTop: 2 }}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          {task.is_completed ? (
            <CheckCircle2 size={24} color="#4CAF50" />
          ) : (
            <Circle size={24} color="#666666" />
          )}
        </TouchableOpacity>
        
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Text
              style={{
                fontSize: 16,
                fontWeight: '600',
                color: task.is_completed ? '#666666' : '#FFFFFF',
                textDecorationLine: task.is_completed ? 'line-through' : 'none',
                flex: 1,
                marginRight: 8,
              }}
              numberOfLines={2}
            >
              {task.title}
            </Text>
            <TouchableOpacity
              onPress={() => handleTaskLongPress(task)}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <MoreVertical size={16} color="#666666" />
            </TouchableOpacity>
          </View>
          
          {task.description ? (
            <Text
              style={{
                fontSize: 14,
                color: '#666666',
                marginTop: 4,
                lineHeight: 20,
              }}
              numberOfLines={2}
            >
              {task.description}
            </Text>
          ) : null}
          
          {renderSubtasks(task.subtasks)}
          
          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8, flexWrap: 'wrap' }}>
            {/* Priority */}
            <View style={{
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: PRIORITY_COLORS[task.priority],
              borderRadius: 12,
              paddingHorizontal: 8,
              paddingVertical: 4,
              marginRight: 8,
              marginBottom: 4,
            }}>
              <Flag size={12} color="#FFFFFF" />
              <Text style={{ fontSize: 12, color: '#FFFFFF', marginLeft: 4, fontWeight: '500' }}>
                {PRIORITY_LABELS[task.priority]}
              </Text>
            </View>
            
            {/* Project */}
            {task.project_name && (
              <View style={{
                backgroundColor: task.project_color || '#333333',
                borderRadius: 12,
                paddingHorizontal: 8,
                paddingVertical: 4,
                marginRight: 8,
                marginBottom: 4,
              }}>
                <Text style={{ fontSize: 12, color: '#FFFFFF', fontWeight: '500' }}>
                  {task.project_name}
                </Text>
              </View>
            )}
            
            {/* Due Date */}
            {task.due_date && (
              <View style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: '#FFC107',
                borderRadius: 12,
                paddingHorizontal: 8,
                paddingVertical: 4,
                marginBottom: 4,
              }}>
                <Calendar size={12} color="#000000" />
                <Text style={{ fontSize: 12, color: '#000000', marginLeft: 4, fontWeight: '500' }}>
                  {formatDueDate(task.due_date)}
                </Text>
              </View>
            )}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderEmptyState = () => (
    <View style={{ 
      flex: 1, 
      justifyContent: 'center', 
      alignItems: 'center',
      paddingHorizontal: 32,
    }}>
      <CheckSquare size={64} color="#666666" />
      <Text style={{ 
        fontSize: 18, 
        fontWeight: '600', 
        color: '#FFFFFF',
        marginTop: 16,
        marginBottom: 8,
        textAlign: 'center',
      }}>
        No tasks yet
      </Text>
      <Text style={{ 
        fontSize: 14, 
        color: '#CCCCCC',
        textAlign: 'center',
        lineHeight: 20,
      }}>
        Tap the + button to create your first task
      </Text>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#000000' }}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={{ 
        paddingTop: insets.top + 16,
        paddingHorizontal: 20,
        paddingBottom: 16,
        backgroundColor: '#000000',
        borderBottomWidth: 1,
        borderBottomColor: '#333333',
      }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ fontSize: 28, fontWeight: '700', color: '#FFFFFF' }}>
            Tasks
          </Text>
          <TouchableOpacity
            onPress={() => setShowCreateModal(true)}
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 20,
              width: 40,
              height: 40,
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <Plus size={24} color="#000000" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Tasks List */}
      {tasks.length === 0 && !isLoading ? (
        renderEmptyState()
      ) : (
        <FlatList
          data={tasks}
          renderItem={renderTaskItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={{ 
            paddingVertical: 8,
            paddingBottom: insets.bottom + 20,
          }}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor="#FFFFFF"
            />
          }
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Create Item Modal */}
      <Modal
        visible={showCreateModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowCreateModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowCreateModal(false)}>
          <View style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.8)',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <TouchableWithoutFeedback onPress={() => {}}>
              <View style={{
                backgroundColor: '#111111',
                margin: 20,
                borderRadius: 12,
                padding: 20,
                width: '90%',
                maxWidth: 400,
              }}>
                <Text style={{
                  color: '#FFFFFF',
                  fontSize: 20,
                  fontWeight: '600',
                  marginBottom: 20,
                }}>
                  Create New Item
                </Text>
                
                {/* Type Selection */}
                <View style={{ flexDirection: 'row', marginBottom: 20 }}>
                  <TouchableOpacity
                    onPress={() => setCreateType('note')}
                    style={{
                      flex: 1,
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: 12,
                      marginRight: 8,
                      borderRadius: 8,
                      backgroundColor: createType === 'note' ? '#2196F3' : '#333333',
                    }}
                  >
                    <FileText color="#FFFFFF" size={16} />
                    <Text style={{ color: '#FFFFFF', marginLeft: 8, fontWeight: '600' }}>Note</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    onPress={() => setCreateType('task')}
                    style={{
                      flex: 1,
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: 12,
                      marginLeft: 8,
                      borderRadius: 8,
                      backgroundColor: createType === 'task' ? '#2196F3' : '#333333',
                    }}
                  >
                    <CheckSquare color="#FFFFFF" size={16} />
                    <Text style={{ color: '#FFFFFF', marginLeft: 8, fontWeight: '600' }}>Task</Text>
                  </TouchableOpacity>
                </View>
                
                <TextInput
                  value={newItemTitle}
                  onChangeText={setNewItemTitle}
                  onSubmitEditing={handleCreateItem}
                  placeholder={createType === 'note' ? 'Note title' : 'Task title'}
                  placeholderTextColor="#666666"
                  style={{
                    backgroundColor: '#222222',
                    color: '#FFFFFF',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 16,
                    borderWidth: 1,
                    borderColor: '#333333',
                  }}
                  autoFocus
                  returnKeyType="done"
                />
                
                {/* Project Selection */}
                <Text style={{ color: '#FFFFFF', fontSize: 16, marginBottom: 8 }}>
                  Project (optional)
                </Text>
                <FlatList
                  data={projects}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  renderItem={({ item: project }) => (
                    <TouchableOpacity
                      onPress={() => {
                        setSelectedProject(selectedProject?.id === project.id ? null : project);
                      }}
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        backgroundColor: selectedProject?.id === project.id ? project.color : '#333333',
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 16,
                        marginRight: 8,
                        borderWidth: 1,
                        borderColor: selectedProject?.id === project.id ? '#FFFFFF' : 'transparent',
                      }}
                    >
                      <Folder color="#FFFFFF" size={12} />
                      <Text style={{ color: '#FFFFFF', fontSize: 12, marginLeft: 4, fontWeight: '600' }}>
                        {project.name}
                      </Text>
                    </TouchableOpacity>
                  )}
                  keyExtractor={(item) => item.id.toString()}
                  style={{ marginBottom: 20 }}
                />
                
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                  <TouchableOpacity
                    onPress={() => {
                      setShowCreateModal(false);
                      setNewItemTitle('');
                      setSelectedProject(null);
                    }}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginRight: 8,
                      borderRadius: 8,
                      backgroundColor: '#333333',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>Cancel</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    onPress={handleCreateItem}
                    disabled={!newItemTitle.trim() || createTaskMutation.isPending || createNoteMutation.isPending}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginLeft: 8,
                      borderRadius: 8,
                      backgroundColor: newItemTitle.trim() ? '#2196F3' : '#555555',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>
                      {(createTaskMutation.isPending || createNoteMutation.isPending) ? 'Creating...' : 'Create'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      {/* Actions Modal */}
      <Modal
        visible={showActionsModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowActionsModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowActionsModal(false)}>
          <View style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.8)',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <View style={{
              backgroundColor: '#111111',
              borderRadius: 12,
              padding: 8,
              minWidth: 200,
            }}>
              <TouchableOpacity
                onPress={() => {
                  handleToggleTask(selectedTask);
                  setShowActionsModal(false);
                }}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 16,
                }}
              >
                {selectedTask?.is_completed ? (
                  <Circle color="#FFFFFF" size={18} />
                ) : (
                  <CheckCircle2 color="#FFFFFF" size={18} />
                )}
                <Text style={{ color: '#FFFFFF', fontSize: 16, marginLeft: 12 }}>
                  Mark {selectedTask?.is_completed ? 'Incomplete' : 'Complete'}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                onPress={() => {
                  setShowActionsModal(false);
                  setShowProjectModal(true);
                }}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 16,
                }}
              >
                <Folder color="#FFFFFF" size={18} />
                <Text style={{ color: '#FFFFFF', fontSize: 16, marginLeft: 12 }}>
                  Assign to Project
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                onPress={handleEditTask}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 16,
                }}
              >
                <Edit color="#FFFFFF" size={18} />
                <Text style={{ color: '#FFFFFF', fontSize: 16, marginLeft: 12 }}>
                  Edit Task
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                onPress={() => {
                  setShowActionsModal(false);
                  setTimeout(handleDeleteTask, 100);
                }}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 16,
                }}
              >
                <Trash2 color="#F44336" size={18} />
                <Text style={{ color: '#F44336', fontSize: 16, marginLeft: 12 }}>
                  Delete Task
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      {/* Project Assignment Modal */}
      <Modal
        visible={showProjectModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowProjectModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowProjectModal(false)}>
          <View style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.8)',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <TouchableWithoutFeedback onPress={() => {}}>
              <View style={{
                backgroundColor: '#111111',
                margin: 20,
                borderRadius: 12,
                padding: 20,
                width: '90%',
                maxWidth: 400,
              }}>
                <Text style={{
                  color: '#FFFFFF',
                  fontSize: 20,
                  fontWeight: '600',
                  marginBottom: 20,
                }}>
                  Assign to Project
                </Text>
                
                {/* None option */}
                <TouchableOpacity
                  onPress={() => handleAssignProject(null)}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: 16,
                    backgroundColor: selectedTask?.project_id === null ? '#333333' : 'transparent',
                    borderRadius: 8,
                    marginBottom: 8,
                  }}
                >
                  <View style={{
                    width: 24,
                    height: 24,
                    borderRadius: 12,
                    backgroundColor: '#666666',
                    marginRight: 12,
                  }} />
                  <Text style={{ color: '#FFFFFF', fontSize: 16 }}>None</Text>
                </TouchableOpacity>
                
                {/* Project options */}
                <FlatList
                  data={projects}
                  renderItem={({ item: project }) => (
                    <TouchableOpacity
                      onPress={() => handleAssignProject(project.id)}
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        padding: 16,
                        backgroundColor: selectedTask?.project_id === project.id ? project.color : 'transparent',
                        borderRadius: 8,
                        marginBottom: 8,
                      }}
                    >
                      <View style={{
                        width: 24,
                        height: 24,
                        borderRadius: 12,
                        backgroundColor: project.color,
                        justifyContent: 'center',
                        alignItems: 'center',
                        marginRight: 12,
                      }}>
                        <Folder color="#FFFFFF" size={12} />
                      </View>
                      <Text style={{ color: '#FFFFFF', fontSize: 16 }}>{project.name}</Text>
                    </TouchableOpacity>
                  )}
                  keyExtractor={(item) => item.id.toString()}
                />
                
                <TouchableOpacity
                  onPress={() => setShowProjectModal(false)}
                  style={{
                    padding: 12,
                    marginTop: 16,
                    borderRadius: 8,
                    backgroundColor: '#333333',
                    alignItems: 'center',
                  }}
                >
                  <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>Cancel</Text>
                </TouchableOpacity>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
}