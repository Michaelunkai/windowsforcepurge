import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Modal,
  TextInput,
  RefreshControl,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { router, useLocalSearchParams } from 'expo-router';
import { 
  ArrowLeft, 
  Plus, 
  FileText, 
  CheckSquare, 
  List,
  MoreVertical,
  Check,
  Pin,
  PinOff,
  Edit,
  Trash2,
  Folder
} from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function ProjectDetailScreen() {
  const { id: projectId } = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createType, setCreateType] = useState('note'); // note, task, list
  const [showActionsModal, setShowActionsModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  
  const [newItem, setNewItem] = useState({
    title: '',
    content: '',
    description: '',
  });

  // Fetch project details
  const { data: project, isLoading: projectLoading } = useQuery({
    queryKey: ['projects', projectId],
    queryFn: async () => {
      const response = await fetch(`/api/projects/${projectId}`);
      if (!response.ok) throw new Error('Failed to fetch project');
      const data = await response.json();
      return data.project;
    },
  });

  // Fetch project notes
  const { data: notes = [], refetch: refetchNotes } = useQuery({
    queryKey: ['notes', { project_id: projectId }],
    queryFn: async () => {
      const response = await fetch(`/api/notes?project_id=${projectId}`);
      if (!response.ok) throw new Error('Failed to fetch notes');
      const data = await response.json();
      return data.notes;
    },
    refetchInterval: 5000,
  });

  // Fetch project tasks
  const { data: tasks = [], refetch: refetchTasks } = useQuery({
    queryKey: ['tasks', { project_id: projectId }],
    queryFn: async () => {
      const response = await fetch(`/api/tasks?project_id=${projectId}`);
      if (!response.ok) throw new Error('Failed to fetch tasks');
      const data = await response.json();
      return data.tasks;
    },
    refetchInterval: 5000,
  });

  // Create note mutation
  const createNoteMutation = useMutation({
    mutationFn: async (noteData) => {
      const response = await fetch('/api/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...noteData, project_id: projectId }),
      });
      if (!response.ok) throw new Error('Failed to create note');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      setShowCreateModal(false);
      setNewItem({ title: '', content: '', description: '' });
    },
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (taskData) => {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...taskData, project_id: projectId }),
      });
      if (!response.ok) throw new Error('Failed to create task');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setShowCreateModal(false);
      setNewItem({ title: '', content: '', description: '' });
    },
  });

  // Toggle task completion
  const toggleTaskMutation = useMutation({
    mutationFn: async ({ taskId, isCompleted }) => {
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_completed: !isCompleted }),
      });
      if (!response.ok) throw new Error('Failed to update task');
      return response.json();
    },
    onMutate: ({ taskId, isCompleted }) => {
      // Optimistic update
      queryClient.setQueryData(['tasks', { project_id: projectId }], (old) =>
        old?.map(task =>
          task.id === taskId ? { ...task, is_completed: !isCompleted } : task
        )
      );
    },
    onError: (error, { taskId, isCompleted }) => {
      // Revert on error
      queryClient.setQueryData(['tasks', { project_id: projectId }], (old) =>
        old?.map(task =>
          task.id === taskId ? { ...task, is_completed: isCompleted } : task
        )
      );
    },
  });

  // Pin/unpin note
  const togglePinMutation = useMutation({
    mutationFn: async ({ noteId, isPinned }) => {
      const response = await fetch(`/api/notes/${noteId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_pinned: !isPinned }),
      });
      if (!response.ok) throw new Error('Failed to update note');
      return response.json();
    },
    onMutate: ({ noteId, isPinned }) => {
      // Optimistic update
      queryClient.setQueryData(['notes', { project_id: projectId }], (old) =>
        old?.map(note =>
          note.id === noteId ? { ...note, is_pinned: !isPinned } : note
        )
      );
    },
  });

  // Delete item mutation
  const deleteItemMutation = useMutation({
    mutationFn: async ({ type, id }) => {
      const response = await fetch(`/api/${type}s/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error(`Failed to delete ${type}`);
      return response.json();
    },
    onSuccess: (data, variables) => {
      if (variables.type === 'note') {
        queryClient.invalidateQueries({ queryKey: ['notes'] });
      } else if (variables.type === 'task') {
        queryClient.invalidateQueries({ queryKey: ['tasks'] });
      }
      setShowActionsModal(false);
      setSelectedItem(null);
    },
  });

  const handleCreateItem = useCallback(() => {
    if (!newItem.title.trim()) return;
    
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    
    if (createType === 'note') {
      createNoteMutation.mutate({
        title: newItem.title,
        content: newItem.content,
      });
    } else if (createType === 'task') {
      createTaskMutation.mutate({
        title: newItem.title,
        description: newItem.description,
      });
    }
  }, [newItem, createType, createNoteMutation, createTaskMutation]);

  const handleToggleTask = useCallback((task) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    toggleTaskMutation.mutate({ taskId: task.id, isCompleted: task.is_completed });
  }, [toggleTaskMutation]);

  const handleTogglePin = useCallback((note) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    togglePinMutation.mutate({ noteId: note.id, isPinned: note.is_pinned });
  }, [togglePinMutation]);

  const handleLongPress = useCallback((item, type) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSelectedItem({ ...item, type });
    setShowActionsModal(true);
  }, []);

  const handleDeleteItem = useCallback(() => {
    if (!selectedItem) return;
    
    Alert.alert(
      `Delete ${selectedItem.type === 'note' ? 'Note' : 'Task'}`,
      `Are you sure you want to delete "${selectedItem.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
            deleteItemMutation.mutate({ 
              type: selectedItem.type, 
              id: selectedItem.id 
            });
          },
        },
      ]
    );
  }, [selectedItem, deleteItemMutation]);

  const handleEditItem = useCallback(() => {
    if (!selectedItem) return;
    setShowActionsModal(false);
    router.push(`/(tabs)/${selectedItem.type}/${selectedItem.id}`);
  }, [selectedItem]);

  const combinedData = [
    ...notes.map(note => ({ ...note, type: 'note' })),
    ...tasks.map(task => ({ ...task, type: 'task' }))
  ].sort((a, b) => {
    // Sort by pinned status, then by updated_at
    if (a.is_pinned && !b.is_pinned) return -1;
    if (!a.is_pinned && b.is_pinned) return 1;
    return new Date(b.updated_at || b.created_at) - new Date(a.updated_at || a.created_at);
  });

  const renderItem = useCallback(({ item }) => (
    <TouchableOpacity
      onPress={() => router.push(`/(tabs)/${item.type}/${item.id}`)}
      onLongPress={() => handleLongPress(item, item.type)}
      style={{
        backgroundColor: '#111111',
        marginHorizontal: 16,
        marginVertical: 6,
        padding: 16,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#333333',
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
        {/* Type Icon */}
        <View style={{ marginRight: 12, paddingTop: 2 }}>
          {item.type === 'note' ? (
            <FileText color="#FFFFFF" size={18} />
          ) : (
            <CheckSquare color={item.is_completed ? '#4CAF50' : '#FFFFFF'} size={18} />
          )}
        </View>
        
        {/* Content */}
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
            <Text style={{
              color: item.type === 'task' && item.is_completed ? '#666666' : '#FFFFFF',
              fontSize: 16,
              fontWeight: '600',
              flex: 1,
              textDecorationLine: item.type === 'task' && item.is_completed ? 'line-through' : 'none',
            }}>
              {item.title}
            </Text>
            {item.is_pinned && <Pin color="#FFC107" size={14} style={{ marginLeft: 8 }} />}
          </View>
          
          {(item.content || item.description) && (
            <Text style={{ color: '#666666', fontSize: 14, lineHeight: 18 }} numberOfLines={2}>
              {item.content || item.description}
            </Text>
          )}
        </View>
        
        {/* Task Toggle */}
        {item.type === 'task' && (
          <TouchableOpacity
            onPress={() => handleToggleTask(item)}
            style={{ padding: 8 }}
          >
            <View style={{
              width: 24,
              height: 24,
              borderRadius: 12,
              borderWidth: 2,
              borderColor: item.is_completed ? '#4CAF50' : '#666666',
              backgroundColor: item.is_completed ? '#4CAF50' : 'transparent',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
              {item.is_completed && <Check color="#FFFFFF" size={14} />}
            </View>
          </TouchableOpacity>
        )}
      </View>
    </TouchableOpacity>
  ), [handleLongPress, handleToggleTask]);

  const refetch = useCallback(() => {
    refetchNotes();
    refetchTasks();
  }, [refetchNotes, refetchTasks]);

  if (projectLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: '#000000', justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: '#FFFFFF' }}>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#000000', paddingTop: insets.top }}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={{
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 16,
      }}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginRight: 16 }}
        >
          <ArrowLeft color="#FFFFFF" size={24} />
        </TouchableOpacity>
        
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
          <View
            style={{
              width: 32,
              height: 32,
              borderRadius: 16,
              backgroundColor: project?.color || '#2196F3',
              justifyContent: 'center',
              alignItems: 'center',
              marginRight: 12,
            }}
          >
            <Folder color="#FFFFFF" size={16} />
          </View>
          <Text style={{ color: '#FFFFFF', fontSize: 20, fontWeight: '600' }}>
            {project?.name || 'Project'}
          </Text>
        </View>
        
        <TouchableOpacity
          onPress={() => setShowCreateModal(true)}
          style={{
            backgroundColor: '#2196F3',
            width: 40,
            height: 40,
            borderRadius: 20,
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Plus color="#FFFFFF" size={20} />
        </TouchableOpacity>
      </View>

      {/* Items List */}
      <FlatList
        data={combinedData}
        renderItem={renderItem}
        keyExtractor={(item) => `${item.type}-${item.id}`}
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={refetch}
            tintColor="#FFFFFF"
          />
        }
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
        ListEmptyComponent={() => (
          <View style={{ padding: 40, alignItems: 'center' }}>
            <Text style={{ color: '#666666', fontSize: 16, textAlign: 'center' }}>
              No items in this project yet.{'\n'}Tap the + button to create your first note or task.
            </Text>
          </View>
        )}
      />

      {/* Create Item Modal */}
      <Modal
        visible={showCreateModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowCreateModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowCreateModal(false)}>
          <View style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.8)',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <TouchableWithoutFeedback onPress={() => {}}>
              <View style={{
                backgroundColor: '#111111',
                margin: 20,
                borderRadius: 12,
                padding: 20,
                width: '90%',
                maxWidth: 400,
              }}>
                <Text style={{
                  color: '#FFFFFF',
                  fontSize: 20,
                  fontWeight: '600',
                  marginBottom: 20,
                }}>
                  Create New Item
                </Text>
                
                {/* Type Selection */}
                <View style={{ flexDirection: 'row', marginBottom: 20 }}>
                  <TouchableOpacity
                    onPress={() => setCreateType('note')}
                    style={{
                      flex: 1,
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: 12,
                      marginRight: 8,
                      borderRadius: 8,
                      backgroundColor: createType === 'note' ? '#2196F3' : '#333333',
                    }}
                  >
                    <FileText color="#FFFFFF" size={16} />
                    <Text style={{ color: '#FFFFFF', marginLeft: 8, fontWeight: '600' }}>Note</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    onPress={() => setCreateType('task')}
                    style={{
                      flex: 1,
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                      padding: 12,
                      marginLeft: 8,
                      borderRadius: 8,
                      backgroundColor: createType === 'task' ? '#2196F3' : '#333333',
                    }}
                  >
                    <CheckSquare color="#FFFFFF" size={16} />
                    <Text style={{ color: '#FFFFFF', marginLeft: 8, fontWeight: '600' }}>Task</Text>
                  </TouchableOpacity>
                </View>
                
                <TextInput
                  value={newItem.title}
                  onChangeText={(text) => setNewItem(prev => ({ ...prev, title: text }))}
                  placeholder={createType === 'note' ? 'Note title' : 'Task title'}
                  placeholderTextColor="#666666"
                  style={{
                    backgroundColor: '#222222',
                    color: '#FFFFFF',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 12,
                    borderWidth: 1,
                    borderColor: '#333333',
                  }}
                  autoFocus
                />
                
                <TextInput
                  value={createType === 'note' ? newItem.content : newItem.description}
                  onChangeText={(text) => {
                    if (createType === 'note') {
                      setNewItem(prev => ({ ...prev, content: text }));
                    } else {
                      setNewItem(prev => ({ ...prev, description: text }));
                    }
                  }}
                  placeholder={createType === 'note' ? 'Content (optional)' : 'Description (optional)'}
                  placeholderTextColor="#666666"
                  style={{
                    backgroundColor: '#222222',
                    color: '#FFFFFF',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 20,
                    borderWidth: 1,
                    borderColor: '#333333',
                    minHeight: 80,
                  }}
                  multiline
                />
                
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                  <TouchableOpacity
                    onPress={() => setShowCreateModal(false)}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginRight: 8,
                      borderRadius: 8,
                      backgroundColor: '#333333',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>Cancel</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    onPress={handleCreateItem}
                    disabled={!newItem.title.trim() || createNoteMutation.isPending || createTaskMutation.isPending}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginLeft: 8,
                      borderRadius: 8,
                      backgroundColor: newItem.title.trim() ? '#2196F3' : '#555555',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>
                      {(createNoteMutation.isPending || createTaskMutation.isPending) ? 'Creating...' : 'Create'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      {/* Actions Modal */}
      <Modal
        visible={showActionsModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowActionsModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowActionsModal(false)}>
          <View style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.8)',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <View style={{
              backgroundColor: '#111111',
              borderRadius: 12,
              padding: 8,
              minWidth: 200,
            }}>
              {selectedItem?.type === 'note' && (
                <TouchableOpacity
                  onPress={() => {
                    handleTogglePin(selectedItem);
                    setShowActionsModal(false);
                  }}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: 16,
                  }}
                >
                  {selectedItem.is_pinned ? (
                    <PinOff color="#FFFFFF" size={18} />
                  ) : (
                    <Pin color="#FFFFFF" size={18} />
                  )}
                  <Text style={{ color: '#FFFFFF', fontSize: 16, marginLeft: 12 }}>
                    {selectedItem.is_pinned ? 'Unpin' : 'Pin'} Note
                  </Text>
                </TouchableOpacity>
              )}
              
              <TouchableOpacity
                onPress={handleEditItem}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 16,
                }}
              >
                <Edit color="#FFFFFF" size={18} />
                <Text style={{ color: '#FFFFFF', fontSize: 16, marginLeft: 12 }}>
                  Edit {selectedItem?.type === 'note' ? 'Note' : 'Task'}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                onPress={() => {
                  setShowActionsModal(false);
                  setTimeout(handleDeleteItem, 100);
                }}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 16,
                }}
              >
                <Trash2 color="#F44336" size={18} />
                <Text style={{ color: '#F44336', fontSize: 16, marginLeft: 12 }}>
                  Delete {selectedItem?.type === 'note' ? 'Note' : 'Task'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
}