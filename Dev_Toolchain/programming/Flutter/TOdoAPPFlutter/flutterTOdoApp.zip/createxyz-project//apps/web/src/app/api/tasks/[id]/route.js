import sql from "@/app/api/utils/sql";

// Get single task with subtasks and project information
export async function GET(request, { params }) {
  try {
    const { id } = params;
    const [task] = await sql`
      SELECT t.*, 
             p.name as project_name,
             p.color as project_color,
             json_agg(
               json_build_object(
                 'id', s.id,
                 'title', s.title,
                 'is_completed', s.is_completed,
                 'created_at', s.created_at
               ) ORDER BY s.created_at
             ) FILTER (WHERE s.id IS NOT NULL) as subtasks
      FROM tasks t
      LEFT JOIN projects p ON t.project_id = p.id
      LEFT JOIN subtasks s ON t.id = s.task_id
      WHERE t.id = ${id}
      GROUP BY t.id, p.name, p.color
    `;

    if (!task) {
      return Response.json({ error: "Task not found" }, { status: 404 });
    }

    return Response.json({ task });
  } catch (error) {
    console.error("Error fetching task:", error);
    return Response.json({ error: "Failed to fetch task" }, { status: 500 });
  }
}

// Update task
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();

    // Build dynamic update query
    const updateFields = [];
    const values = [];
    let paramCount = 1;

    if (body.title !== undefined) {
      updateFields.push(`title = $${paramCount}`);
      values.push(body.title);
      paramCount++;
    }

    if (body.description !== undefined) {
      updateFields.push(`description = $${paramCount}`);
      values.push(body.description);
      paramCount++;
    }

    if (body.is_completed !== undefined) {
      updateFields.push(`is_completed = $${paramCount}`);
      values.push(body.is_completed);
      paramCount++;
    }

    if (body.priority !== undefined) {
      updateFields.push(`priority = $${paramCount}`);
      values.push(body.priority);
      paramCount++;
    }

    if (body.due_date !== undefined) {
      updateFields.push(`due_date = $${paramCount}`);
      values.push(body.due_date);
      paramCount++;
    }

    if (body.project_id !== undefined) {
      updateFields.push(`project_id = $${paramCount}`);
      values.push(body.project_id);
      paramCount++;
    }

    if (updateFields.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(id);

    const query = `
      UPDATE tasks 
      SET ${updateFields.join(", ")}
      WHERE id = $${paramCount}
      RETURNING *
    `;

    const [task] = await sql(query, values);

    if (!task) {
      return Response.json({ error: "Task not found" }, { status: 404 });
    }

    return Response.json({ task });
  } catch (error) {
    console.error("Error updating task:", error);
    return Response.json({ error: "Failed to update task" }, { status: 500 });
  }
}

// Delete task
export async function DELETE(request, { params }) {
  try {
    const { id } = params;
    const [task] = await sql`
      DELETE FROM tasks WHERE id = ${id} RETURNING *
    `;

    if (!task) {
      return Response.json({ error: "Task not found" }, { status: 404 });
    }

    return Response.json({ message: "Task deleted successfully" });
  } catch (error) {
    console.error("Error deleting task:", error);
    return Response.json({ error: "Failed to delete task" }, { status: 500 });
  }
}
