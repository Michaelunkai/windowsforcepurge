import sql from "@/app/api/utils/sql";

// Get all projects
export async function GET() {
  try {
    const projects = await sql`
      SELECT p.*, 
             COUNT(DISTINCT n.id) as note_count,
             COUNT(DISTINCT t.id) as task_count
      FROM projects p
      LEFT JOIN notes n ON p.id = n.project_id
      LEFT JOIN tasks t ON p.id = t.project_id
      GROUP BY p.id
      ORDER BY p.name
    `;
    return Response.json({ projects });
  } catch (error) {
    console.error('Error fetching projects:', error);
    return Response.json({ error: 'Failed to fetch projects' }, { status: 500 });
  }
}

// Create new project
export async function POST(request) {
  try {
    const { name, color = '#1976D2', description = '' } = await request.json();
    
    if (!name) {
      return Response.json({ error: 'Project name is required' }, { status: 400 });
    }
    
    const [project] = await sql`
      INSERT INTO projects (name, color, description, updated_at)
      VALUES (${name}, ${color}, ${description}, CURRENT_TIMESTAMP)
      RETURNING *
    `;
    
    return Response.json({ project });
  } catch (error) {
    console.error('Error creating project:', error);
    if (error.code === '23505') { // Unique constraint violation
      return Response.json({ error: 'Project name already exists' }, { status: 409 });
    }
    return Response.json({ error: 'Failed to create project' }, { status: 500 });
  }
}