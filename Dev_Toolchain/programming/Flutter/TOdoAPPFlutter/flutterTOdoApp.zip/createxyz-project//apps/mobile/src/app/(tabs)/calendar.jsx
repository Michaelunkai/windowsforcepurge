import React, { useState, useCallback, useMemo } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  FlatList,
  Alert,
  Modal,
  TextInput,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar } from "react-native-calendars";
import {
  Plus,
  CheckCircle2,
  Circle,
  Flag,
  MoreVertical,
  Edit3,
  FileText,
  CheckSquare,
  List,
  Folder,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

const PRIORITY_COLORS = {
  urgent: "#FF5722",
  high: "#FF9800",
  medium: "#2196F3",
  low: "#4CAF50",
};

const CALENDAR_THEME = {
  backgroundColor: "#000000",
  calendarBackground: "#000000",
  textSectionTitleColor: "#FFFFFF",
  textSectionTitleDisabledColor: "#666666",
  selectedDayBackgroundColor: "#FFFFFF",
  selectedDayTextColor: "#000000",
  todayTextColor: "#FFFFFF",
  dayTextColor: "#FFFFFF",
  textDisabledColor: "#666666",
  dotColor: "#FFFFFF",
  selectedDotColor: "#000000",
  arrowColor: "#FFFFFF",
  disabledArrowColor: "#666666",
  monthTextColor: "#FFFFFF",
  indicatorColor: "#FFFFFF",
  textDayFontFamily: "System",
  textMonthFontFamily: "System",
  textDayHeaderFontFamily: "System",
  textDayFontSize: 16,
  textMonthFontSize: 16,
  textDayHeaderFontSize: 13,
};

export default function CalendarScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0],
  );

  // Quick creation state
  const [quickTaskTitle, setQuickTaskTitle] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createType, setCreateType] = useState("task");
  const [selectedProject, setSelectedProject] = useState(null);

  // Fetch projects for project selection
  const { data: projects = [] } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      if (!response.ok) throw new Error("Failed to fetch projects");
      const data = await response.json();
      return data.projects;
    },
    refetchInterval: 5000,
  });

  // Fetch tasks for all dates to show on calendar
  const { data: allTasksData } = useQuery({
    queryKey: ["tasks", "all"],
    queryFn: async () => {
      const response = await fetch("/api/tasks");
      if (!response.ok) {
        throw new Error("Failed to fetch tasks");
      }
      return response.json();
    },
  });

  // Fetch tasks for selected date
  const { data: selectedDateTasks, isLoading } = useQuery({
    queryKey: ["tasks", "date", selectedDate],
    queryFn: async () => {
      const response = await fetch(`/api/tasks?date=${selectedDate}`);
      if (!response.ok) {
        throw new Error("Failed to fetch tasks");
      }
      return response.json();
    },
    enabled: !!selectedDate,
  });

  const allTasks = allTasksData?.tasks || [];
  const tasks = selectedDateTasks?.tasks || [];

  // Quick create task mutation
  const quickCreateTaskMutation = useMutation({
    mutationFn: async (taskData) => {
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(taskData),
      });
      if (!response.ok) throw new Error("Failed to create task");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      setQuickTaskTitle("");
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    },
    onError: () => {
      Alert.alert("Error", "Failed to create task");
    },
  });

  // Create note mutation
  const createNoteMutation = useMutation({
    mutationFn: async (noteData) => {
      const response = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(noteData),
      });
      if (!response.ok) throw new Error("Failed to create note");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notes"] });
      setShowCreateModal(false);
      setQuickTaskTitle("");
      setSelectedProject(null);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    },
  });

  // Toggle task completion mutation
  const toggleTaskMutation = useMutation({
    mutationFn: async ({ id, is_completed }) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_completed: !is_completed }),
      });
      if (!response.ok) {
        throw new Error("Failed to update task");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
    },
    onError: () => {
      Alert.alert("Error", "Failed to update task");
    },
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) {
        throw new Error("Failed to delete task");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
    },
    onError: () => {
      Alert.alert("Error", "Failed to delete task");
    },
  });

  // Prepare marked dates for calendar
  const markedDates = useMemo(() => {
    const marked = {};

    // Mark selected date
    marked[selectedDate] = {
      selected: true,
      selectedColor: "#FFFFFF",
      selectedTextColor: "#000000",
    };

    // Mark dates with tasks
    allTasks.forEach((task) => {
      if (task.due_date) {
        const dateString = new Date(task.due_date).toISOString().split("T")[0];
        if (dateString === selectedDate) {
          // Selected date with tasks
          marked[dateString] = {
            ...marked[dateString],
            marked: true,
            dotColor: "#000000",
          };
        } else {
          // Other dates with tasks
          marked[dateString] = {
            marked: true,
            dotColor: "#FFFFFF",
          };
        }
      }
    });

    return marked;
  }, [allTasks, selectedDate]);

  const handleDateSelect = useCallback((day) => {
    setSelectedDate(day.dateString);
  }, []);

  const handleQuickCreateTask = useCallback(() => {
    if (!quickTaskTitle.trim()) return;

    quickCreateTaskMutation.mutate({
      title: quickTaskTitle.trim(),
      due_date: selectedDate,
      project_id: selectedProject?.id || null,
    });
  }, [quickTaskTitle, selectedDate, selectedProject, quickCreateTaskMutation]);

  const handleCreateFromModal = useCallback(() => {
    if (!quickTaskTitle.trim()) return;

    if (createType === "task") {
      quickCreateTaskMutation.mutate({
        title: quickTaskTitle.trim(),
        due_date: selectedDate,
        project_id: selectedProject?.id || null,
      });
    } else if (createType === "note") {
      createNoteMutation.mutate({
        title: quickTaskTitle.trim(),
        project_id: selectedProject?.id || null,
      });
    }

    setQuickTaskTitle("");
    setShowCreateModal(false);
    setSelectedProject(null);
  }, [
    quickTaskTitle,
    selectedDate,
    selectedProject,
    createType,
    quickCreateTaskMutation,
    createNoteMutation,
  ]);

  const handleTaskPress = useCallback(
    (taskId) => {
      router.push(`/(tabs)/task/${taskId}`);
    },
    [router],
  );

  const handleToggleTask = useCallback(
    (task) => {
      toggleTaskMutation.mutate({
        id: task.id,
        is_completed: task.is_completed,
      });
    },
    [toggleTaskMutation],
  );

  const handleTaskOptions = useCallback(
    (task) => {
      Alert.alert(task.title, "Choose an action", [
        {
          text: task.is_completed ? "Mark Incomplete" : "Mark Complete",
          onPress: () => handleToggleTask(task),
        },
        {
          text: "Edit",
          onPress: () => handleTaskPress(task.id),
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => deleteTaskMutation.mutate(task.id),
        },
        { text: "Cancel", style: "cancel" },
      ]);
    },
    [handleToggleTask, handleTaskPress, deleteTaskMutation],
  );

  const handleTaskLongPress = useCallback(
    (task) => {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      handleTaskOptions(task);
    },
    [handleTaskOptions],
  );

  const renderTaskItem = ({ item: task }) => (
    <TouchableOpacity
      style={{
        backgroundColor: "#1A1A1A",
        borderRadius: 12,
        padding: 16,
        marginHorizontal: 16,
        marginVertical: 4,
        borderWidth: 1,
        borderColor: "#333333",
        opacity: task.is_completed ? 0.6 : 1,
      }}
      onPress={() => handleTaskPress(task.id)}
      onLongPress={() => handleTaskLongPress(task)}
      activeOpacity={0.7}
    >
      <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
        <TouchableOpacity
          onPress={() => handleToggleTask(task)}
          style={{ marginRight: 12, marginTop: 2 }}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          {task.is_completed ? (
            <CheckCircle2 size={24} color="#4CAF50" />
          ) : (
            <Circle size={24} color="#666666" />
          )}
        </TouchableOpacity>

        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: task.is_completed ? "#666666" : "#FFFFFF",
              textDecorationLine: task.is_completed ? "line-through" : "none",
              marginBottom: 4,
            }}
            numberOfLines={2}
          >
            {task.title}
          </Text>

          {task.description ? (
            <Text
              style={{
                fontSize: 14,
                color: "#CCCCCC",
                marginBottom: 8,
                lineHeight: 20,
              }}
              numberOfLines={2}
            >
              {task.description}
            </Text>
          ) : null}

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            {/* Priority */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: PRIORITY_COLORS[task.priority],
                borderRadius: 12,
                paddingHorizontal: 8,
                paddingVertical: 4,
                marginRight: 8,
                marginBottom: 4,
              }}
            >
              <Flag size={12} color="#FFFFFF" />
              <Text
                style={{
                  fontSize: 12,
                  color: "#FFFFFF",
                  marginLeft: 4,
                  fontWeight: "500",
                }}
              >
                {task.priority}
              </Text>
            </View>

            {/* Project */}
            {task.project_name && (
              <View
                style={{
                  backgroundColor: task.project_color || "#333333",
                  borderRadius: 12,
                  paddingHorizontal: 8,
                  paddingVertical: 4,
                  marginBottom: 4,
                }}
              >
                <Text
                  style={{ fontSize: 12, color: "#FFFFFF", fontWeight: "500" }}
                >
                  {task.project_name}
                </Text>
              </View>
            )}
          </View>
        </View>

        <TouchableOpacity
          onPress={() => handleTaskOptions(task)}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <MoreVertical size={16} color="#666666" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  const renderQuickCreateInput = () => (
    <View
      style={{
        backgroundColor: "#111111",
        marginHorizontal: 16,
        marginVertical: 8,
        paddingHorizontal: 16,
        paddingVertical: 12,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: "#333333",
        flexDirection: "row",
        alignItems: "center",
      }}
    >
      <CheckSquare color="#666666" size={20} style={{ marginRight: 12 }} />
      <TextInput
        value={quickTaskTitle}
        onChangeText={setQuickTaskTitle}
        onSubmitEditing={handleQuickCreateTask}
        placeholder={`Add task for ${new Date(selectedDate).toLocaleDateString()}`}
        placeholderTextColor="#666666"
        style={{
          flex: 1,
          color: "#FFFFFF",
          fontSize: 16,
        }}
        returnKeyType="done"
        blurOnSubmit={false}
      />
      {selectedProject && (
        <View
          style={{
            backgroundColor: selectedProject.color,
            paddingHorizontal: 8,
            paddingVertical: 4,
            borderRadius: 6,
            marginLeft: 8,
          }}
        >
          <Text style={{ color: "#FFFFFF", fontSize: 12, fontWeight: "600" }}>
            {selectedProject.name}
          </Text>
        </View>
      )}
    </View>
  );

  const renderEmptyState = () => (
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        paddingHorizontal: 32,
        paddingVertical: 40,
      }}
    >
      <Edit3 size={64} color="#666666" />
      <Text
        style={{
          fontSize: 18,
          fontWeight: "600",
          color: "#FFFFFF",
          marginTop: 16,
          marginBottom: 8,
          textAlign: "center",
        }}
      >
        No tasks for {selectedDate}
      </Text>
      <Text
        style={{
          fontSize: 14,
          color: "#CCCCCC",
          textAlign: "center",
          lineHeight: 20,
        }}
      >
        Type in the field above and press Enter to quickly create a task
      </Text>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: "#000000" }}>
      <StatusBar style="light" />

      {/* Header */}
      <View
        style={{
          paddingTop: insets.top + 16,
          paddingHorizontal: 20,
          paddingBottom: 16,
          backgroundColor: "#000000",
          borderBottomWidth: 1,
          borderBottomColor: "#333333",
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Text style={{ fontSize: 28, fontWeight: "700", color: "#FFFFFF" }}>
            Calendar
          </Text>
          <TouchableOpacity
            onPress={() => setShowCreateModal(true)}
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 20,
              width: 40,
              height: 40,
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Plus size={24} color="#000000" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Calendar */}
      <Calendar
        onDayPress={handleDateSelect}
        markedDates={markedDates}
        theme={CALENDAR_THEME}
        enableSwipeMonths={true}
        hideExtraDays={true}
        firstDay={1}
        showWeekNumbers={false}
      />

      {/* Selected Date Header */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingVertical: 16,
          borderBottomWidth: 1,
          borderBottomColor: "#333333",
        }}
      >
        <Text style={{ fontSize: 20, fontWeight: "600", color: "#FFFFFF" }}>
          Tasks for{" "}
          {new Date(selectedDate).toLocaleDateString("en-US", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </Text>
        <Text style={{ fontSize: 14, color: "#CCCCCC", marginTop: 4 }}>
          {tasks.length} task{tasks.length !== 1 ? "s" : ""}
        </Text>
      </View>

      {/* Quick Create Input */}
      {renderQuickCreateInput()}

      {/* Tasks List */}
      {tasks.length === 0 && !isLoading ? (
        renderEmptyState()
      ) : (
        <FlatList
          data={tasks}
          renderItem={renderTaskItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={{
            paddingVertical: 8,
            paddingBottom: insets.bottom + 20,
          }}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Create Item Modal */}
      <Modal
        visible={showCreateModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowCreateModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowCreateModal(false)}>
          <View
            style={{
              flex: 1,
              backgroundColor: "rgba(0,0,0,0.8)",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <TouchableWithoutFeedback onPress={() => {}}>
              <View
                style={{
                  backgroundColor: "#111111",
                  margin: 20,
                  borderRadius: 12,
                  padding: 20,
                  width: "90%",
                  maxWidth: 400,
                }}
              >
                <Text
                  style={{
                    color: "#FFFFFF",
                    fontSize: 20,
                    fontWeight: "600",
                    marginBottom: 20,
                  }}
                >
                  Create New Item
                </Text>

                {/* Type Selection */}
                <View style={{ flexDirection: "row", marginBottom: 20 }}>
                  <TouchableOpacity
                    onPress={() => setCreateType("note")}
                    style={{
                      flex: 1,
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                      padding: 12,
                      marginRight: 8,
                      borderRadius: 8,
                      backgroundColor:
                        createType === "note" ? "#2196F3" : "#333333",
                    }}
                  >
                    <FileText color="#FFFFFF" size={16} />
                    <Text
                      style={{
                        color: "#FFFFFF",
                        marginLeft: 8,
                        fontWeight: "600",
                      }}
                    >
                      Note
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={() => setCreateType("task")}
                    style={{
                      flex: 1,
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                      padding: 12,
                      marginLeft: 8,
                      borderRadius: 8,
                      backgroundColor:
                        createType === "task" ? "#2196F3" : "#333333",
                    }}
                  >
                    <CheckSquare color="#FFFFFF" size={16} />
                    <Text
                      style={{
                        color: "#FFFFFF",
                        marginLeft: 8,
                        fontWeight: "600",
                      }}
                    >
                      Task
                    </Text>
                  </TouchableOpacity>
                </View>

                <TextInput
                  value={quickTaskTitle}
                  onChangeText={setQuickTaskTitle}
                  onSubmitEditing={handleCreateFromModal}
                  placeholder={
                    createType === "note" ? "Note title" : "Task title"
                  }
                  placeholderTextColor="#666666"
                  style={{
                    backgroundColor: "#222222",
                    color: "#FFFFFF",
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 16,
                    borderWidth: 1,
                    borderColor: "#333333",
                  }}
                  autoFocus
                  returnKeyType="done"
                />

                {/* Project Selection */}
                <Text
                  style={{ color: "#FFFFFF", fontSize: 16, marginBottom: 8 }}
                >
                  Project (optional)
                </Text>
                <FlatList
                  data={projects}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  renderItem={({ item: project }) => (
                    <TouchableOpacity
                      onPress={() => {
                        setSelectedProject(
                          selectedProject?.id === project.id ? null : project,
                        );
                      }}
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        backgroundColor:
                          selectedProject?.id === project.id
                            ? project.color
                            : "#333333",
                        paddingHorizontal: 12,
                        paddingVertical: 8,
                        borderRadius: 16,
                        marginRight: 8,
                        borderWidth: 1,
                        borderColor:
                          selectedProject?.id === project.id
                            ? "#FFFFFF"
                            : "transparent",
                      }}
                    >
                      <Folder color="#FFFFFF" size={12} />
                      <Text
                        style={{
                          color: "#FFFFFF",
                          fontSize: 12,
                          marginLeft: 4,
                          fontWeight: "600",
                        }}
                      >
                        {project.name}
                      </Text>
                    </TouchableOpacity>
                  )}
                  keyExtractor={(item) => item.id.toString()}
                  style={{ marginBottom: 20 }}
                />

                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                  }}
                >
                  <TouchableOpacity
                    onPress={() => {
                      setShowCreateModal(false);
                      setQuickTaskTitle("");
                      setSelectedProject(null);
                    }}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginRight: 8,
                      borderRadius: 8,
                      backgroundColor: "#333333",
                      alignItems: "center",
                    }}
                  >
                    <Text style={{ color: "#FFFFFF", fontWeight: "600" }}>
                      Cancel
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={handleCreateFromModal}
                    disabled={
                      !quickTaskTitle.trim() ||
                      quickCreateTaskMutation.isPending ||
                      createNoteMutation.isPending
                    }
                    style={{
                      flex: 1,
                      padding: 12,
                      marginLeft: 8,
                      borderRadius: 8,
                      backgroundColor: quickTaskTitle.trim()
                        ? "#2196F3"
                        : "#555555",
                      alignItems: "center",
                    }}
                  >
                    <Text style={{ color: "#FFFFFF", fontWeight: "600" }}>
                      {quickCreateTaskMutation.isPending ||
                      createNoteMutation.isPending
                        ? "Creating..."
                        : "Create"}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
}
