import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Modal,
  TextInput,
  Alert,
  RefreshControl,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Plus, Folder, MoreVertical, Edit, Trash2 } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';

const colors = [
  '#2196F3', '#4CAF50', '#FF9800', '#9C27B0', '#F44336',
  '#00BCD4', '#8BC34A', '#FFC107', '#E91E63', '#673AB7',
  '#009688', '#CDDC39', '#FF5722', '#795548', '#607D8B'
];

export default function ProjectsScreen() {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showActionsModal, setShowActionsModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  
  const [newProject, setNewProject] = useState({
    name: '',
    description: '',
    color: colors[0]
  });
  
  const [editProject, setEditProject] = useState({
    id: null,
    name: '',
    description: '',
    color: colors[0]
  });

  // Fetch projects
  const { data: projects = [], isLoading, refetch } = useQuery({
    queryKey: ['projects'],
    queryFn: async () => {
      const response = await fetch('/api/projects');
      if (!response.ok) throw new Error('Failed to fetch projects');
      const data = await response.json();
      return data.projects;
    },
    refetchInterval: 5000,
  });

  // Create project mutation
  const createMutation = useMutation({
    mutationFn: async (projectData) => {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(projectData),
      });
      if (!response.ok) throw new Error('Failed to create project');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setShowCreateModal(false);
      setNewProject({ name: '', description: '', color: colors[0] });
    },
  });

  // Update project mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, ...projectData }) => {
      const response = await fetch(`/api/projects/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(projectData),
      });
      if (!response.ok) throw new Error('Failed to update project');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setShowEditModal(false);
      setEditProject({ id: null, name: '', description: '', color: colors[0] });
    },
  });

  // Delete project mutation
  const deleteMutation = useMutation({
    mutationFn: async (projectId) => {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete project');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setShowActionsModal(false);
      setSelectedProject(null);
    },
  });

  const handleCreateProject = useCallback(() => {
    if (!newProject.name.trim()) return;
    
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    createMutation.mutate(newProject);
  }, [newProject, createMutation]);

  const handleUpdateProject = useCallback(() => {
    if (!editProject.name.trim()) return;
    
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    updateMutation.mutate(editProject);
  }, [editProject, updateMutation]);

  const handleDeleteProject = useCallback((project) => {
    Alert.alert(
      'Delete Project',
      `Are you sure you want to delete "${project.name}"? This will unassign all notes and tasks from this project.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
            deleteMutation.mutate(project.id);
          },
        },
      ]
    );
  }, [deleteMutation]);

  const handleLongPress = useCallback((project) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSelectedProject(project);
    setShowActionsModal(true);
  }, []);

  const handleEditProject = useCallback((project) => {
    setEditProject({
      id: project.id,
      name: project.name,
      description: project.description || '',
      color: project.color
    });
    setShowActionsModal(false);
    setShowEditModal(true);
  }, []);

  const renderProject = useCallback(({ item: project }) => (
    <TouchableOpacity
      onPress={() => router.push(`/(tabs)/project/${project.id}`)}
      onLongPress={() => handleLongPress(project)}
      style={{
        backgroundColor: '#111111',
        marginHorizontal: 16,
        marginVertical: 6,
        padding: 16,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#333333',
        flexDirection: 'row',
        alignItems: 'center',
      }}
    >
      <View
        style={{
          width: 40,
          height: 40,
          borderRadius: 20,
          backgroundColor: project.color,
          justifyContent: 'center',
          alignItems: 'center',
          marginRight: 12,
        }}
      >
        <Folder color="#FFFFFF" size={20} />
      </View>
      
      <View style={{ flex: 1 }}>
        <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: '600' }}>
          {project.name}
        </Text>
        {project.description ? (
          <Text style={{ color: '#666666', fontSize: 14, marginTop: 2 }}>
            {project.description}
          </Text>
        ) : null}
      </View>
      
      <TouchableOpacity
        onPress={() => handleLongPress(project)}
        style={{ padding: 8 }}
      >
        <MoreVertical color="#666666" size={16} />
      </TouchableOpacity>
    </TouchableOpacity>
  ), [handleLongPress]);

  const renderColorPicker = useCallback((selectedColor, onColorSelect) => (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 16 }}>
      {colors.map((color) => (
        <TouchableOpacity
          key={color}
          onPress={() => onColorSelect(color)}
          style={{
            width: 40,
            height: 40,
            borderRadius: 20,
            backgroundColor: color,
            margin: 4,
            borderWidth: selectedColor === color ? 3 : 0,
            borderColor: '#FFFFFF',
          }}
        />
      ))}
    </View>
  ), []);

  return (
    <View style={{ flex: 1, backgroundColor: '#000000', paddingTop: insets.top }}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={{
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingVertical: 16,
      }}>
        <Text style={{ color: '#FFFFFF', fontSize: 28, fontWeight: '700' }}>
          Projects
        </Text>
        <TouchableOpacity
          onPress={() => setShowCreateModal(true)}
          style={{
            backgroundColor: '#2196F3',
            width: 40,
            height: 40,
            borderRadius: 20,
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Plus color="#FFFFFF" size={20} />
        </TouchableOpacity>
      </View>

      {/* Projects List */}
      <FlatList
        data={projects}
        renderItem={renderProject}
        keyExtractor={(item) => item.id.toString()}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={refetch}
            tintColor="#FFFFFF"
          />
        }
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
      />

      {/* Create Project Modal */}
      <Modal
        visible={showCreateModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowCreateModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowCreateModal(false)}>
          <View style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.8)',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <TouchableWithoutFeedback onPress={() => {}}>
              <View style={{
                backgroundColor: '#111111',
                margin: 20,
                borderRadius: 12,
                padding: 20,
                width: '90%',
                maxWidth: 400,
              }}>
                <Text style={{
                  color: '#FFFFFF',
                  fontSize: 20,
                  fontWeight: '600',
                  marginBottom: 20,
                }}>
                  Create New Project
                </Text>
                
                <TextInput
                  value={newProject.name}
                  onChangeText={(text) => setNewProject(prev => ({ ...prev, name: text }))}
                  placeholder="Project name"
                  placeholderTextColor="#666666"
                  style={{
                    backgroundColor: '#222222',
                    color: '#FFFFFF',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 12,
                    borderWidth: 1,
                    borderColor: '#333333',
                  }}
                  autoFocus
                />
                
                <TextInput
                  value={newProject.description}
                  onChangeText={(text) => setNewProject(prev => ({ ...prev, description: text }))}
                  placeholder="Description (optional)"
                  placeholderTextColor="#666666"
                  style={{
                    backgroundColor: '#222222',
                    color: '#FFFFFF',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 12,
                    borderWidth: 1,
                    borderColor: '#333333',
                  }}
                  multiline
                />
                
                <Text style={{ color: '#FFFFFF', fontSize: 16, marginBottom: 8 }}>
                  Color
                </Text>
                {renderColorPicker(newProject.color, (color) => 
                  setNewProject(prev => ({ ...prev, color }))
                )}
                
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginTop: 20,
                }}>
                  <TouchableOpacity
                    onPress={() => setShowCreateModal(false)}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginRight: 8,
                      borderRadius: 8,
                      backgroundColor: '#333333',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>Cancel</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    onPress={handleCreateProject}
                    disabled={!newProject.name.trim() || createMutation.isPending}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginLeft: 8,
                      borderRadius: 8,
                      backgroundColor: newProject.name.trim() ? '#2196F3' : '#555555',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>
                      {createMutation.isPending ? 'Creating...' : 'Create'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      {/* Edit Project Modal */}
      <Modal
        visible={showEditModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowEditModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowEditModal(false)}>
          <View style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.8)',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <TouchableWithoutFeedback onPress={() => {}}>
              <View style={{
                backgroundColor: '#111111',
                margin: 20,
                borderRadius: 12,
                padding: 20,
                width: '90%',
                maxWidth: 400,
              }}>
                <Text style={{
                  color: '#FFFFFF',
                  fontSize: 20,
                  fontWeight: '600',
                  marginBottom: 20,
                }}>
                  Edit Project
                </Text>
                
                <TextInput
                  value={editProject.name}
                  onChangeText={(text) => setEditProject(prev => ({ ...prev, name: text }))}
                  placeholder="Project name"
                  placeholderTextColor="#666666"
                  style={{
                    backgroundColor: '#222222',
                    color: '#FFFFFF',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 12,
                    borderWidth: 1,
                    borderColor: '#333333',
                  }}
                  autoFocus
                />
                
                <TextInput
                  value={editProject.description}
                  onChangeText={(text) => setEditProject(prev => ({ ...prev, description: text }))}
                  placeholder="Description (optional)"
                  placeholderTextColor="#666666"
                  style={{
                    backgroundColor: '#222222',
                    color: '#FFFFFF',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 12,
                    borderWidth: 1,
                    borderColor: '#333333',
                  }}
                  multiline
                />
                
                <Text style={{ color: '#FFFFFF', fontSize: 16, marginBottom: 8 }}>
                  Color
                </Text>
                {renderColorPicker(editProject.color, (color) => 
                  setEditProject(prev => ({ ...prev, color }))
                )}
                
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginTop: 20,
                }}>
                  <TouchableOpacity
                    onPress={() => setShowEditModal(false)}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginRight: 8,
                      borderRadius: 8,
                      backgroundColor: '#333333',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>Cancel</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    onPress={handleUpdateProject}
                    disabled={!editProject.name.trim() || updateMutation.isPending}
                    style={{
                      flex: 1,
                      padding: 12,
                      marginLeft: 8,
                      borderRadius: 8,
                      backgroundColor: editProject.name.trim() ? '#2196F3' : '#555555',
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>
                      {updateMutation.isPending ? 'Saving...' : 'Save'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      {/* Actions Modal */}
      <Modal
        visible={showActionsModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowActionsModal(false)}
      >
        <TouchableWithoutFeedback onPress={() => setShowActionsModal(false)}>
          <View style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.8)',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
            <View style={{
              backgroundColor: '#111111',
              borderRadius: 12,
              padding: 8,
              minWidth: 200,
            }}>
              <TouchableOpacity
                onPress={() => handleEditProject(selectedProject)}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 16,
                }}
              >
                <Edit color="#FFFFFF" size={18} />
                <Text style={{ color: '#FFFFFF', fontSize: 16, marginLeft: 12 }}>
                  Edit Project
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                onPress={() => {
                  setShowActionsModal(false);
                  setTimeout(() => handleDeleteProject(selectedProject), 100);
                }}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 16,
                }}
              >
                <Trash2 color="#F44336" size={18} />
                <Text style={{ color: '#F44336', fontSize: 16, marginLeft: 12 }}>
                  Delete Project
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </View>
  );
}