import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  ArrowLeft, 
  Check, 
  Flag, 
  Calendar, 
  FolderOpen,
  Plus,
  X,
  MoreVertical
} from 'lucide-react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import KeyboardAvoidingAnimatedView from '@/components/KeyboardAvoidingAnimatedView';

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low', color: '#4CAF50' },
  { value: 'medium', label: 'Medium', color: '#2196F3' },
  { value: 'high', label: 'High', color: '#FF9800' },
  { value: 'urgent', label: 'Urgent', color: '#FF5722' },
];

const PROJECT_OPTIONS = ['Inbox', 'Work', 'Personal', 'Health', 'Shopping'];

export default function TaskEditorScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const queryClient = useQueryClient();
  const isNewTask = id === 'new';

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('medium');
  const [project, setProject] = useState('Inbox');
  const [dueDate, setDueDate] = useState('');
  const [subtasks, setSubtasks] = useState([]);
  const [newSubtask, setNewSubtask] = useState('');
  const [hasChanges, setHasChanges] = useState(false);

  // Fetch existing task
  const { data: taskData, isLoading } = useQuery({
    queryKey: ['task', id],
    queryFn: async () => {
      if (isNewTask) return null;
      const response = await fetch(`/api/tasks/${id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch task');
      }
      return response.json();
    },
    enabled: !isNewTask,
  });

  // Initialize form with existing task data
  useEffect(() => {
    if (taskData?.task && !isNewTask) {
      const task = taskData.task;
      setTitle(task.title || '');
      setDescription(task.description || '');
      setPriority(task.priority || 'medium');
      setProject(task.project || 'Inbox');
      setDueDate(task.due_date ? new Date(task.due_date).toISOString().split('T')[0] : '');
      setSubtasks(task.subtasks || []);
    }
  }, [taskData, isNewTask]);

  // Track changes
  useEffect(() => {
    if (!isNewTask && taskData?.task) {
      const originalTask = taskData.task;
      const originalDueDate = originalTask.due_date ? new Date(originalTask.due_date).toISOString().split('T')[0] : '';
      const hasChanged = 
        title !== (originalTask.title || '') ||
        description !== (originalTask.description || '') ||
        priority !== (originalTask.priority || 'medium') ||
        project !== (originalTask.project || 'Inbox') ||
        dueDate !== originalDueDate ||
        JSON.stringify(subtasks) !== JSON.stringify(originalTask.subtasks || []);
      setHasChanges(hasChanged);
    } else if (isNewTask) {
      setHasChanges(title.trim() !== '');
    }
  }, [title, description, priority, project, dueDate, subtasks, taskData, isNewTask]);

  // Save task mutation
  const saveTaskMutation = useMutation({
    mutationFn: async (taskData) => {
      const url = isNewTask ? '/api/tasks' : `/api/tasks/${id}`;
      const method = isNewTask ? 'POST' : 'PUT';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(taskData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to save task');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['task', id] });
      setHasChanges(false);
      router.back();
    },
    onError: () => {
      Alert.alert('Error', 'Failed to save task');
    },
  });

  // Delete task mutation
  const deleteTaskMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/tasks/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error('Failed to delete task');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      router.back();
    },
    onError: () => {
      Alert.alert('Error', 'Failed to delete task');
    },
  });

  const handleSave = useCallback(() => {
    if (!title.trim()) {
      Alert.alert('Error', 'Task title is required');
      return;
    }

    if (!hasChanges) {
      router.back();
      return;
    }

    const taskData = {
      title: title.trim(),
      description: description.trim(),
      priority,
      project,
      due_date: dueDate ? new Date(dueDate).toISOString() : null,
      subtasks: subtasks.map(st => st.title).filter(Boolean),
    };

    saveTaskMutation.mutate(taskData);
  }, [title, description, priority, project, dueDate, subtasks, hasChanges, saveTaskMutation, router]);

  const handleBack = useCallback(() => {
    if (hasChanges) {
      Alert.alert(
        'Unsaved Changes',
        'You have unsaved changes. What would you like to do?',
        [
          { text: 'Discard', style: 'destructive', onPress: () => router.back() },
          { text: 'Save', onPress: handleSave },
          { text: 'Cancel', style: 'cancel' },
        ]
      );
    } else {
      router.back();
    }
  }, [hasChanges, handleSave, router]);

  const handleDelete = useCallback(() => {
    if (isNewTask) return;
    
    Alert.alert(
      'Delete Task',
      'Are you sure you want to delete this task?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive', 
          onPress: () => deleteTaskMutation.mutate() 
        },
      ]
    );
  }, [isNewTask, deleteTaskMutation]);

  const handleMoreOptions = useCallback(() => {
    const options = [];

    if (!isNewTask) {
      options.push({ 
        text: 'Delete', 
        style: 'destructive',
        onPress: handleDelete 
      });
    }

    options.push({ text: 'Cancel', style: 'cancel' });

    Alert.alert('Task Options', 'Choose an action', options);
  }, [isNewTask, handleDelete]);

  const addSubtask = useCallback(() => {
    if (newSubtask.trim()) {
      setSubtasks([...subtasks, { title: newSubtask.trim(), is_completed: false }]);
      setNewSubtask('');
    }
  }, [newSubtask, subtasks]);

  const removeSubtask = useCallback((index) => {
    setSubtasks(subtasks.filter((_, i) => i !== index));
  }, [subtasks]);

  const renderPrioritySelector = () => (
    <View style={{ marginBottom: 24 }}>
      <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 12 }}>
        Priority
      </Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {PRIORITY_OPTIONS.map((option) => (
          <TouchableOpacity
            key={option.value}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: priority === option.value ? option.color : '#F3F4F6',
              borderRadius: 20,
              paddingHorizontal: 16,
              paddingVertical: 8,
              marginRight: 8,
              marginBottom: 8,
            }}
            onPress={() => setPriority(option.value)}
          >
            <Flag size={16} color={priority === option.value ? '#FFFFFF' : option.color} />
            <Text
              style={{
                color: priority === option.value ? '#FFFFFF' : '#666',
                fontWeight: '500',
                marginLeft: 6,
              }}
            >
              {option.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderProjectSelector = () => (
    <View style={{ marginBottom: 24 }}>
      <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 12 }}>
        Project
      </Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {PROJECT_OPTIONS.map((projectOption) => (
          <TouchableOpacity
            key={projectOption}
            style={{
              backgroundColor: project === projectOption ? '#1976D2' : '#F3F4F6',
              borderRadius: 20,
              paddingHorizontal: 16,
              paddingVertical: 8,
              marginRight: 8,
              marginBottom: 8,
            }}
            onPress={() => setProject(projectOption)}
          >
            <Text
              style={{
                color: project === projectOption ? '#FFFFFF' : '#666',
                fontWeight: '500',
              }}
            >
              {projectOption}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderSubtasks = () => (
    <View style={{ marginBottom: 24 }}>
      <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 12 }}>
        Subtasks
      </Text>
      
      {subtasks.map((subtask, index) => (
        <View
          key={index}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: '#F8F9FA',
            borderRadius: 8,
            padding: 12,
            marginBottom: 8,
          }}
        >
          <Text style={{ flex: 1, color: '#333' }}>{subtask.title}</Text>
          <TouchableOpacity onPress={() => removeSubtask(index)}>
            <X size={20} color="#666" />
          </TouchableOpacity>
        </View>
      ))}
      
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TextInput
          value={newSubtask}
          onChangeText={setNewSubtask}
          placeholder="Add subtask"
          style={{
            flex: 1,
            backgroundColor: '#F8F9FA',
            borderRadius: 8,
            padding: 12,
            marginRight: 8,
            color: '#333',
          }}
          placeholderTextColor="#999"
          onSubmitEditing={addSubtask}
          returnKeyType="done"
        />
        <TouchableOpacity
          onPress={addSubtask}
          style={{
            backgroundColor: '#1976D2',
            borderRadius: 8,
            padding: 12,
          }}
        >
          <Plus size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
    </View>
  );

  if (isLoading && !isNewTask) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingAnimatedView style={{ flex: 1 }} behavior="padding">
      <View style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
        <StatusBar style="dark" />
        
        {/* Header */}
        <View style={{ 
          paddingTop: insets.top + 16,
          paddingHorizontal: 20,
          paddingBottom: 16,
          backgroundColor: '#FFFFFF',
          borderBottomWidth: 1,
          borderBottomColor: '#E5E7EB',
        }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <TouchableOpacity onPress={handleBack}>
              <ArrowLeft size={24} color="#333" />
            </TouchableOpacity>
            
            <Text style={{ fontSize: 18, fontWeight: '600', color: '#333' }}>
              {isNewTask ? 'New Task' : 'Edit Task'}
            </Text>
            
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              {!isNewTask && (
                <TouchableOpacity onPress={handleMoreOptions} style={{ marginRight: 12 }}>
                  <MoreVertical size={24} color="#333" />
                </TouchableOpacity>
              )}
              <TouchableOpacity
                onPress={handleSave}
                disabled={!title.trim() || saveTaskMutation.isLoading}
                style={{
                  backgroundColor: title.trim() ? '#1976D2' : '#E5E7EB',
                  borderRadius: 20,
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                }}
              >
                <Check size={20} color={title.trim() ? '#FFFFFF' : '#999'} />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Task Content */}
        <ScrollView 
          style={{ flex: 1 }}
          contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 20 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Title */}
          <View style={{ marginBottom: 24 }}>
            <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 8 }}>
              Title *
            </Text>
            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="Task title"
              style={{
                backgroundColor: '#F8F9FA',
                borderRadius: 8,
                padding: 16,
                fontSize: 16,
                color: '#333',
              }}
              placeholderTextColor="#999"
            />
          </View>

          {/* Description */}
          <View style={{ marginBottom: 24 }}>
            <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 8 }}>
              Description
            </Text>
            <TextInput
              value={description}
              onChangeText={setDescription}
              placeholder="Task description"
              style={{
                backgroundColor: '#F8F9FA',
                borderRadius: 8,
                padding: 16,
                fontSize: 16,
                color: '#333',
                minHeight: 100,
                textAlignVertical: 'top',
              }}
              multiline
              placeholderTextColor="#999"
            />
          </View>

          {/* Due Date */}
          <View style={{ marginBottom: 24 }}>
            <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 8 }}>
              Due Date
            </Text>
            <TextInput
              value={dueDate}
              onChangeText={setDueDate}
              placeholder="YYYY-MM-DD"
              style={{
                backgroundColor: '#F8F9FA',
                borderRadius: 8,
                padding: 16,
                fontSize: 16,
                color: '#333',
              }}
              placeholderTextColor="#999"
            />
          </View>

          {renderPrioritySelector()}
          {renderProjectSelector()}
          {renderSubtasks()}
        </ScrollView>
      </View>
    </KeyboardAvoidingAnimatedView>
  );
}