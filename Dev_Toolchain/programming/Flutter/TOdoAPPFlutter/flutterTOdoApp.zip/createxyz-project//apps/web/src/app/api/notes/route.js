import sql from "@/app/api/utils/sql";

// Get all notes with project information
export async function GET() {
  try {
    const notes = await sql`
      SELECT n.*, p.name as project_name, p.color as project_color
      FROM notes n
      LEFT JOIN projects p ON n.project_id = p.id
      ORDER BY n.is_pinned DESC, n.updated_at DESC
    `;
    return Response.json({ notes });
  } catch (error) {
    console.error("Error fetching notes:", error);
    return Response.json({ error: "Failed to fetch notes" }, { status: 500 });
  }
}

// Create new note
export async function POST(request) {
  try {
    const {
      title = "",
      content = "",
      color = "#FFFFFF",
      is_pinned = false,
      project_id,
    } = await request.json();

    const [note] = await sql`
      INSERT INTO notes (title, content, color, is_pinned, project_id, updated_at)
      VALUES (${title}, ${content}, ${color}, ${is_pinned}, ${project_id || null}, CURRENT_TIMESTAMP)
      RETURNING *
    `;

    return Response.json({ note });
  } catch (error) {
    console.error("Error creating note:", error);
    return Response.json({ error: "Failed to create note" }, { status: 500 });
  }
}
