import sql from "@/app/api/utils/sql";

// Get single note with project information
export async function GET(request, { params }) {
  try {
    const { id } = params;
    const [note] = await sql`
      SELECT n.*, p.name as project_name, p.color as project_color
      FROM notes n
      LEFT JOIN projects p ON n.project_id = p.id
      WHERE n.id = ${id}
    `;

    if (!note) {
      return Response.json({ error: "Note not found" }, { status: 404 });
    }

    return Response.json({ note });
  } catch (error) {
    console.error("Error fetching note:", error);
    return Response.json({ error: "Failed to fetch note" }, { status: 500 });
  }
}

// Update note
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();

    // Build dynamic update query
    const updateFields = [];
    const values = [];
    let paramCount = 1;

    if (body.title !== undefined) {
      updateFields.push(`title = $${paramCount}`);
      values.push(body.title);
      paramCount++;
    }

    if (body.content !== undefined) {
      updateFields.push(`content = $${paramCount}`);
      values.push(body.content);
      paramCount++;
    }

    if (body.color !== undefined) {
      updateFields.push(`color = $${paramCount}`);
      values.push(body.color);
      paramCount++;
    }

    if (body.is_pinned !== undefined) {
      updateFields.push(`is_pinned = $${paramCount}`);
      values.push(body.is_pinned);
      paramCount++;
    }

    if (body.project_id !== undefined) {
      updateFields.push(`project_id = $${paramCount}`);
      values.push(body.project_id);
      paramCount++;
    }

    if (updateFields.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
    values.push(id);

    const query = `
      UPDATE notes 
      SET ${updateFields.join(", ")}
      WHERE id = $${paramCount}
      RETURNING *
    `;

    const [note] = await sql(query, values);

    if (!note) {
      return Response.json({ error: "Note not found" }, { status: 404 });
    }

    return Response.json({ note });
  } catch (error) {
    console.error("Error updating note:", error);
    return Response.json({ error: "Failed to update note" }, { status: 500 });
  }
}

// Delete note
export async function DELETE(request, { params }) {
  try {
    const { id } = params;
    const [note] = await sql`
      DELETE FROM notes WHERE id = ${id} RETURNING *
    `;

    if (!note) {
      return Response.json({ error: "Note not found" }, { status: 404 });
    }

    return Response.json({ message: "Note deleted successfully" });
  } catch (error) {
    console.error("Error deleting note:", error);
    return Response.json({ error: "Failed to delete note" }, { status: 500 });
  }
}
