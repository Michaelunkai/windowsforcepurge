// // // A variable is a container for storing data
// // // a variable behaves as if it was the value that it contains

// // // two steps:
// // // 1. Declaration (car, let, const)
// // // 2. Assignment (= assignment operator)

// // // let age;
// // // age = 21;

// // // or:
// // // let age = 21;

// // let firstName = "Misha";  //strings
// // let age = 21; //numbers
// // let student = true; //booleans
// // // or = false;

// // // age = age + 1;
// // // this will make my age 22. but!! if i would have used 
// // // string ("21") and not a number (21) i would get age = 211.


// // console.log(age);
// // console.log(age);
// // console.log(student);



// let firstName = "Misha";  //strings
// let age = 21; //numbers
// let student = true; //booleans


// console.log("Hello", firstName);
// console.log("you are", age, "years old");
// console.log(student);

// // output:
// // Hello Misha
// // you are 21 years old
// // true

let firstName = "Misha";  //strings
let age = 21; //numbers
let student = true; //booleans

console.log("Hello", firstName);
console.log("you are", age, "years old");
console.log("Enrolled:", student);

document.getElementById("p1").innerHTML = "Hello " + firstName;
document.getElementById("p2").innerHTML = "You are " + age + " years old";
document.getElementById("p3").innerHTML = "Enrolled: " + student;