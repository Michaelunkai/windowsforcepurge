document.addEventListener("DOMContentLoaded", function() {
    console.log("Script loaded and running");
});
