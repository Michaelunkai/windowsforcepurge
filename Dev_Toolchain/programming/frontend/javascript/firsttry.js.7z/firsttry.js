// app.js
const message = 'Hello, JavaScript!';
console.log(message);
