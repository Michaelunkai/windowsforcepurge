getnpm && sudo npm install pm2 -g && pm2 start app.js
