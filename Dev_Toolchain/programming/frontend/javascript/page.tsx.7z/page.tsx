import { EnhancedNotebook } from "@/components/enhanced-notebook"

export default function Page() {
  return <EnhancedNotebook />
}