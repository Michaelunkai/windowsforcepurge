import { MichaTickets } from "@/components/micha-tickets"

export default function Page() {
  return <MichaTickets />
}