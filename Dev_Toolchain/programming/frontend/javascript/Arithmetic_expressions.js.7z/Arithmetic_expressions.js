// // // // Arithmetic expressions 

// // // /*
// // // Arithmetic expressions in JavaScript combine numbers
// // //  and operators like +, -, *, /, %. They follow
// // // operator precedence and can include parentheses
// // // for grouping. Operations can involve integers,
// // // floats, or variables. JavaScript evaluates
// // // expressions from left to right, converting data
// // // types if necessary. NaN may result from invalid
// // // operations.
// // // */

// // // let students = 20;
// // // students = students +1;
// // // console.log(students);
// // // // output: 21

// // // let students = 21;

// // // students = students + 1;
// // // students = students - 1;
// // // students = students * 2;
// // // students = students / 2;


// // let students = 21;

// // let extraStudents = 2 - (students % 2);

// // console.log(extraStudents); // Output will be 1

// let students = 20;
// students = students ** 2;

// console.log(students);

//  ortcut:
let students = 20;
students -=1;
// output: 19
console.log(students)