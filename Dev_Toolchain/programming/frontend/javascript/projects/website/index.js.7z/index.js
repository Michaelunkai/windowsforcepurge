console.log(" I like Food!");
console.log("Its awasome!")

window.alert("I REALLY LOVE FOOD!!")

//This is a commet

/*

This
is
a
multieline
comment

*/