#!/bin/ 
sudo apt install nano && nano