#!/bin/ 
sudo apt install gedit && gedit