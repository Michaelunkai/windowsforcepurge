import subprocess
import nmap
from scapy.all import *
from netaddr import IPNetwork
import datetime

# Define the network to scan
network = "192.168.1.0/24"
# Define the report file
report_file = "pentest_report.txt"

# Function to write to report
def write_report(data):
    with open(report_file, 'a') as report:
        report.write(data + '\n')

# Function to perform a ping sweep
def ping_sweep(network):
    write_report(f"Performing ping sweep on {network}...")
    active_hosts = []
    for ip in IPNetwork(network):
        resp = sr1(IP(dst=str(ip))/ICMP(), timeout=1, verbose=0)
        if resp is None:
            continue
        elif int(resp.getlayer(ICMP).type) == 0:
            write_report(f"Host {ip} is up")
            active_hosts.append(str(ip))
    return active_hosts

# Function to perform a port scan using nmap
def port_scan(ip):
    write_report(f"\nScanning ports on {ip}...")
    nm = nmap.PortScanner()
    nm.scan(ip, '1-1024', '-sV')
    for host in nm.all_hosts():
        write_report(f"Host: {host}")
        for proto in nm[host].all_protocols():
            write_report(f"Protocol: {proto}")
            lport = nm[host][proto].keys()
            for port in lport:
                report_line = f"Port: {port}\tState: {nm[host][proto][port]['state']}\tService: {nm[host][proto][port]['name']}"
                write_report(report_line)

# Function to enumerate a web server
def web_enum(ip):
    write_report(f"\nEnumerating web server on {ip}...")
    try:
        result = subprocess.run(['gobuster', 'dir', '-u', f"http://{ip}", '-w', '/usr/share/wordlists/dirb/common.txt', '-t', '50'], capture_output=True, text=True)
        write_report(result.stdout)
    except subprocess.CalledProcessError as e:
        write_report(f"Error during gobuster execution: {e}")

# Function to perform vulnerability scan using nmap scripts
def vuln_scan(ip):
    write_report(f"\nPerforming vulnerability scan on {ip}...")
    nm = nmap.PortScanner()
    nm.scan(ip, arguments='--script vuln')
    for host in nm.all_hosts():
        write_report(f"Host: {host}")
        for proto in nm[host].all_protocols():
            lport = nm[host][proto].keys()
            for port in lport:
                if 'script' in nm[host][proto][port]:
                    for script in nm[host][proto][port]['script']:
                        report_line = f"Port: {port}\tScript: {script}\tOutput: {nm[host][proto][port]['script'][script]}"
                        write_report(report_line)

# Main function
def main():
    # Start the report
    with open(report_file, 'w') as report:
        report.write(f"Penetration Test Report\n")
        report.write(f"Start Time: {datetime.datetime.now()}\n")
        report.write("="*50 + "\n")

    active_hosts = ping_sweep(network)
    for host in active_hosts:
        port_scan(host)
        # Perform vulnerability scan on each host
        vuln_scan(host)
        # If port 80 or 443 is open, run web enumeration
        nm = nmap.PortScanner()
        nm.scan(host, '80,443')
        if host in nm.all_hosts():
            if nm[host].has_tcp(80) and nm[host]['tcp'][80]['state'] == 'open':
                web_enum(host)
            if nm[host].has_tcp(443) and nm[host]['tcp'][443]['state'] == 'open':
                web_enum(host)

    # End the report
    with open(report_file, 'a') as report:
        report.write("="*50 + "\n")
        report.write(f"End Time: {datetime.datetime.now()}\n")

if __name__ == "__main__":
    main()
