#!/bin/bash
logfile="/mnt/c/Users/micha/Downloads/exam.log"

grep -c "ERROR" "$logfile"
