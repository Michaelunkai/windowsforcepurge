run:

sudo apt update && sudo apt install npm -y && npm install && npm run
