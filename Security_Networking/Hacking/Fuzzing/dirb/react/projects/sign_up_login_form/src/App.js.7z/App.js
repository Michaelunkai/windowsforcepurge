import './App.css';
import LoginSignup from './Components/LoginSignUp/LoginSignup';

function App() {
  return (
    <div>
     <LoginSignup/>
    </div>
  );
}

export default App;
