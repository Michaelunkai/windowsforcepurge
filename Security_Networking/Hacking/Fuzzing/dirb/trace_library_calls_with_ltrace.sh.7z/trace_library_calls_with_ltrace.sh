#!/bin/ 
ltrace /usr/bin/ls > ltrace_output.txt
