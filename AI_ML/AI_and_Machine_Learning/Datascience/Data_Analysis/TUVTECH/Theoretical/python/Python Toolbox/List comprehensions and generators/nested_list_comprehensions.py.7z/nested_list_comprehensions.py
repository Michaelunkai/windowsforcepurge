
# Create a 5x5 matrix using nested list comprehensions
matrix = [[col for col in range(5)] for row in range(5)]

# Print the matrix
for row in matrix:
    print(row)
