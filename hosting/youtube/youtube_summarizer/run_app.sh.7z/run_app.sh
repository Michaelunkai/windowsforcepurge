#!/bin/bash
python3 /mnt/c/study/programming/python/apps/youtube/youtube_summarizer/a.py
